/**
 * Enterprise Cryptographic Engine for SI-ARSIF HAJI
 * Uses Web Crypto API for AES-GCM 256-bit encryption, PBKDF2 key derivation,
 * and SHA-256 integrity checksums.
 */

// Helper to convert ArrayBuffer to Base64
export function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

// Helper to convert Base64 to ArrayBuffer
export function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// Compute SHA-256 checksum string for any text or binary input
export async function computeSHA256(content: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(content);
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch (err) {
    console.error('Failed to compute SHA256:', err);
    // Simple fallback hash
    let hash = 0;
    for (let i = 0; i < content.length; i++) {
      hash = (hash << 5) - hash + content.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16).padStart(32, '0');
  }
}

// Derive a 256-bit CryptoKey from a passphrase and salt using PBKDF2
async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    encoder.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export interface EncryptedPayload {
  ciphertext: string; // Base64
  iv: string; // Base64
  salt: string; // Base64
  sha256: string;
}

/**
 * Encrypt arbitrary plain text or base64 file string with AES-GCM 256-bit
 */
export async function encryptDocument(
  plainContent: string,
  passphrase: string
): Promise<EncryptedPayload> {
  const encoder = new TextEncoder();
  const plainBytes = encoder.encode(plainContent);

  // Generate 16 bytes salt for PBKDF2
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  // Generate 12 bytes IV for AES-GCM
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  const key = await deriveKey(passphrase, salt);

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv as BufferSource,
    },
    key,
    plainBytes
  );

  const sha256 = await computeSHA256(plainContent);

  return {
    ciphertext: bufferToBase64(encryptedBuffer),
    iv: bufferToBase64(iv.buffer),
    salt: bufferToBase64(salt.buffer),
    sha256,
  };
}

/**
 * Decrypt AES-GCM ciphertext using the given passphrase, IV, and salt
 */
export async function decryptDocument(
  ciphertextBase64: string,
  ivBase64: string,
  saltBase64: string,
  passphrase: string
): Promise<{ success: boolean; content?: string; error?: string }> {
  try {
    const ciphertext = base64ToBuffer(ciphertextBase64);
    const iv = new Uint8Array(base64ToBuffer(ivBase64));
    const salt = new Uint8Array(base64ToBuffer(saltBase64));

    const key = await deriveKey(passphrase, salt);

    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as BufferSource,
      },
      key,
      ciphertext
    );

    const decoder = new TextDecoder();
    const plainText = decoder.decode(decryptedBuffer);

    return {
      success: true,
      content: plainText,
    };
  } catch (err: any) {
    return {
      success: false,
      error: 'Kata sandi / Kunci enkripsi salah atau dokumen telah rusak/diubah (Integrity Check Failed).',
    };
  }
}

// Generate audit hash for log tamper evidence
export function generateAuditHash(
  timestamp: string,
  nip: string,
  action: string,
  targetId: string = ''
): string {
  const raw = `${timestamp}::${nip}::${action}::${targetId}::BUDIKA_HAJI_SEC`;
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    hash = (hash << 5) - hash + raw.charCodeAt(i);
    hash |= 0;
  }
  return 'AUDIT-' + Math.abs(hash).toString(16).toUpperCase().padStart(12, '0');
}
