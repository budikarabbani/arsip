import { getAccessToken } from './firebase';

const DRIVE_UPLOAD_URL = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
const DRIVE_API_URL = 'https://www.googleapis.com/drive/v3/files';
export const APP_FOLDER_NAME = 'BUDIKA-ARSIF-HAJI';

export interface DriveFileInfo {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
}

/**
 * Locate or create the dedicated folder in the user's Google Drive
 */
export async function getOrCreateAppFolder(): Promise<string | null> {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    // Check if folder already exists
    const query = encodeURIComponent(
      `name = '${APP_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`
    );
    const searchRes = await fetch(`${DRIVE_API_URL}?q=${query}&fields=files(id, name)`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!searchRes.ok) {
      console.warn('Drive folder search failed:', await searchRes.text());
      return null;
    }

    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      return searchData.files[0].id;
    }

    // Create the folder
    const createRes = await fetch(DRIVE_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: APP_FOLDER_NAME,
        mimeType: 'application/vnd.google-apps.folder',
        description: 'Penyimpanan Resmi Dokumen Kearsipan Digital Kementerian Haji dan Umrah Republik Indonesia',
      }),
    });

    if (!createRes.ok) {
      console.warn('Drive folder create failed:', await createRes.text());
      return null;
    }

    const createdData = await createRes.json();
    return createdData.id;
  } catch (err) {
    console.error('Error in getOrCreateAppFolder:', err);
    return null;
  }
}

/**
 * Upload a document (raw or encrypted) to Google Drive in the app folder
 */
export async function uploadToGoogleDrive(params: {
  fileName: string;
  content: string; // Plaintext, base64 or JSON
  mimeType: string;
  isEncrypted: boolean;
  metadataDescription?: string;
}): Promise<{ success: boolean; fileId?: string; webViewLink?: string; error?: string }> {
  const token = await getAccessToken();
  if (!token) {
    return {
      success: false,
      error: 'Akun Google Drive belum terhubung atau sesi telah berakhir. Silakan login Google Drive.',
    };
  }

  try {
    const folderId = await getOrCreateAppFolder();

    const metadata = {
      name: params.fileName,
      mimeType: params.mimeType || 'application/json',
      parents: folderId ? [folderId] : undefined,
      description: params.metadataDescription || 'Arsip Digital Kementerian Haji dan Umrah',
      properties: {
        system: 'SI-ARSIF-HAJI',
        encrypted: params.isEncrypted ? 'true' : 'false',
        archivedAt: new Date().toISOString(),
      },
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      `Content-Type: ${params.mimeType || 'text/plain'}\r\n\r\n` +
      params.content +
      closeDelimiter;

    const res = await fetch(DRIVE_UPLOAD_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    });

    if (!res.ok) {
      const errText = await res.text();
      return { success: false, error: `Google Drive Error (${res.status}): ${errText}` };
    }

    const data = await res.json();

    // Fetch webViewLink
    let webViewLink = `https://drive.google.com/file/d/${data.id}/view`;
    try {
      const detailRes = await fetch(`${DRIVE_API_URL}/${data.id}?fields=webViewLink,name,id`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (detailRes.ok) {
        const detailData = await detailRes.json();
        if (detailData.webViewLink) webViewLink = detailData.webViewLink;
      }
    } catch {
      // ignore
    }

    return {
      success: true,
      fileId: data.id,
      webViewLink,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Terjadi kesalahan saat mengunggah ke Google Drive',
    };
  }
}

/**
 * List files saved in the BUDIKA-ARSIF-HAJI folder
 */
export async function listAppDriveFiles(): Promise<DriveFileInfo[]> {
  const token = await getAccessToken();
  if (!token) return [];

  try {
    const folderId = await getOrCreateAppFolder();
    if (!folderId) return [];

    const query = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
    const res = await fetch(
      `${DRIVE_API_URL}?q=${query}&fields=files(id, name, mimeType, webViewLink, size, createdTime, modifiedTime)&orderBy=modifiedTime desc`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (!res.ok) return [];
    const data = await res.json();
    return data.files || [];
  } catch (err) {
    console.error('Failed to list drive files:', err);
    return [];
  }
}
