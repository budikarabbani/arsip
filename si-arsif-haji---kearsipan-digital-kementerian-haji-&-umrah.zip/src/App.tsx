import React from 'react';
import { ArchiveProvider, useArchive } from './context/ArchiveContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { DashboardView } from './components/DashboardView';
import { ArchiveListView } from './components/ArchiveListView';
import { PersonnelFilesView } from './components/PersonnelFilesView';
import { EncryptedVaultView } from './components/EncryptedVaultView';
import { AuditLogView } from './components/AuditLogView';
import { GoogleDriveAndBackupView } from './components/GoogleDriveAndBackupView';
import { RoleManagementView } from './components/RoleManagementView';
import { AdminPanelUsersView } from './components/AdminPanelUsersView';
import { UploadModal } from './components/UploadModal';
import { DocumentDetailModal } from './components/DocumentDetailModal';

const MainLayout: React.FC = () => {
  const { activeTab } = useArchive();

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans antialiased flex flex-col">
      <Header />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        <Sidebar />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 pb-24 md:pb-12 max-w-full overflow-hidden">
          {activeTab === 'dashboard' && <DashboardView />}
          {activeTab === 'archives' && <ArchiveListView />}
          {activeTab === 'personnel' && <PersonnelFilesView />}
          {activeTab === 'admin_users' && <AdminPanelUsersView />}
          {activeTab === 'vault' && <EncryptedVaultView />}
          {activeTab === 'audit' && <AuditLogView />}
          {activeTab === 'backup' && <GoogleDriveAndBackupView />}
          {activeTab === 'roles' && <RoleManagementView />}
        </main>
      </div>

      <MobileNav />
      <UploadModal />
      <DocumentDetailModal />
    </div>
  );
};

export default function App() {
  return (
    <ArchiveProvider>
      <MainLayout />
    </ArchiveProvider>
  );
}
