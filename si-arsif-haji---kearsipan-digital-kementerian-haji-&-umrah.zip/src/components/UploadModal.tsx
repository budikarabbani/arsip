import React, { useState, useEffect } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { ArchiveCategory, SecurityLevel, PersonnelType } from '../types/archive';
import {
  X,
  Upload,
  Sparkles,
  Lock,
  CloudCheck,
  FileText,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

export const UploadModal: React.FC = () => {
  const {
    isUploadModalOpen,
    setIsUploadModalOpen,
    uploadInitialPersonnelOnly,
    setUploadInitialPersonnelOnly,
    currentUser,
    addDocument,
    isGoogleConnected,
  } = useArchive();

  // Form states
  const [file, setFile] = useState<File | null>(null);
  const [fileContentSnippet, setFileContentSnippet] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [docNumber, setDocNumber] = useState<string>('');
  const [category, setCategory] = useState<ArchiveCategory>('Surat Dinas & Disposisi');
  const [subCategory, setSubCategory] = useState<string>('Surat Masuk Kementerian Haji & Umrah');
  const [securityLevel, setSecurityLevel] = useState<SecurityLevel>('Terbatas');
  const [isPersonnelFile, setIsPersonnelFile] = useState<boolean>(false);
  const [personnelType, setPersonnelType] = useState<PersonnelType>('SK_KENAIKAN_PANGKAT');
  const [personnelOwnerNip, setPersonnelOwnerNip] = useState<string>(currentUser.nip);
  const [personnelOwnerName, setPersonnelOwnerName] = useState<string>(currentUser.name);
  const [summary, setSummary] = useState<string>('');
  const [keywords, setKeywords] = useState<string>('haji, kementerian, dokumen');
  const [retentionYears, setRetentionYears] = useState<number>(5);
  const [retentionAction, setRetentionAction] = useState<'Permanen' | 'Musnah' | 'Dinilai Kembali'>('Dinilai Kembali');
  const [isEncrypted, setIsEncrypted] = useState<boolean>(false);
  const [passphrase, setPassphrase] = useState<string>('');
  const [useCustomPassphrase, setUseCustomPassphrase] = useState<boolean>(false);

  // AI analysis state
  const [isAnalyzingAI, setIsAnalyzingAI] = useState<boolean>(false);
  const [aiResult, setAiResult] = useState<any | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (uploadInitialPersonnelOnly) {
      setIsPersonnelFile(true);
      setCategory('Kepegawaian & Petugas Haji');
      setSubCategory('SK Kenaikan Pangkat Jabatan Fungsional');
      setPersonnelOwnerNip(currentUser.nip);
      setPersonnelOwnerName(currentUser.name);
    }
  }, [uploadInitialPersonnelOnly, currentUser]);

  if (!isUploadModalOpen) return null;

  const handleClose = () => {
    setIsUploadModalOpen(false);
    setUploadInitialPersonnelOnly(false);
    setFile(null);
    setFileContentSnippet('');
    setAiResult(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      if (!title) {
        setTitle(selected.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          setFileContentSnippet(text.slice(0, 4000));
        }
      };
      if (selected.type.includes('text') || selected.name.endsWith('.txt')) {
        reader.readAsText(selected);
      } else {
        setFileContentSnippet(`Nama Berkas: ${selected.name}, Ukuran: ${selected.size} bytes`);
      }
    }
  };

  const handleRunAICategorization = async () => {
    if (!title && !file?.name) {
      alert('Silakan pilih berkas atau ketikkan judul dokumen terlebih dahulu.');
      return;
    }

    setIsAnalyzingAI(true);
    setAiError(null);

    try {
      const res = await fetch('/api/ai/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file?.name || title,
          fileContentSnippet: fileContentSnippet || title,
          notes: summary,
          currentCategory: category,
        }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        const data = json.data;
        setAiResult(data);

        if (data.category) setCategory(data.category);
        if (data.subCategory) setSubCategory(data.subCategory);
        if (data.securityLevel) setSecurityLevel(data.securityLevel);
        if (data.summary) setSummary(data.summary);
        if (data.keywords && Array.isArray(data.keywords)) setKeywords(data.keywords.join(', '));
        if (data.suggestedDocNumber && !docNumber) setDocNumber(data.suggestedDocNumber);
        if (data.retentionYears) setRetentionYears(data.retentionYears);
        if (data.retentionAction) setRetentionAction(data.retentionAction);
        if (data.isPersonnelFile !== undefined) setIsPersonnelFile(data.isPersonnelFile);
        if (data.personnelType) setPersonnelType(data.personnelType);
        if (data.isConfidentialRecommended || data.securityLevel === 'Rahasia' || data.securityLevel === 'Sangat Rahasia') {
          setIsEncrypted(true);
        }
      } else {
        setAiError(json.error || 'AI tidak dapat menyimpulkan dokumen.');
      }
    } catch (err: any) {
      setAiError(err.message || 'Gagal menghubungi layanan AI.');
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      alert('Judul dokumen wajib diisi.');
      return;
    }

    setIsSubmitting(true);

    try {
      const generatedDocNumber = docNumber.trim() || `B-${Math.floor(100 + Math.random() * 900)}/KEMEN.HAJI/SET/${new Date().getFullYear()}`;
      const keywordArray = keywords
        .split(',')
        .map((k) => k.trim())
        .filter(Boolean);

      const res = await addDocument(
        {
          title: title.trim(),
          docNumber: generatedDocNumber,
          category,
          subCategory: subCategory.trim() || 'Dokumen Resmi Kementerian Haji & Umrah',
          securityLevel,
          status: currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'PEJABAT_VERIFIKATOR' ? 'Diarsipkan' : 'Menunggu Verifikasi',
          isEncrypted,
          fileName: file?.name || `${title.replace(/\s+/g, '_')}.pdf`,
          fileType: file ? file.name.split('.').pop() || 'pdf' : 'pdf',
          fileSize: file ? file.size : 1024000,
          year: new Date().getFullYear(),
          retentionExpiry: `${new Date().getFullYear() + retentionYears}-12-31`,
          retentionYears,
          retentionAction,
          ownerNip: currentUser.nip,
          ownerName: currentUser.name,
          ownerEmail: currentUser.email,
          ownerUnit: currentUser.unit,
          isPersonnelFile,
          personnelType: isPersonnelFile ? personnelType : undefined,
          personnelOwnerNip: isPersonnelFile ? personnelOwnerNip : undefined,
          personnelOwnerName: isPersonnelFile ? personnelOwnerName : undefined,
          summary: summary.trim() || 'Dokumen kearsipan resmi Kementerian Haji dan Umrah Republik Indonesia.',
          keywords: keywordArray.length > 0 ? keywordArray : ['arsip', 'haji'],
          aiClassified: !!aiResult,
          aiReasoning: aiResult?.aiReasoning,
        },
        fileContentSnippet || summary || title,
        useCustomPassphrase ? passphrase : 'BUDIKA-ARSIF-HAJI-SECURE-2026'
      );

      if (res.success) {
        handleClose();
      } else {
        alert(res.error || 'Gagal menyimpan berkas.');
      }
    } catch (err: any) {
      alert(err.message || 'Terjadi kesalahan sistem.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-900 border border-amber-300">
              <Upload className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-950">
                Unggah Berkas Baru • BUDIKA ARSIP
              </h2>
              <p className="text-xs text-slate-500">
                Kementerian Haji dan Umrah RI • Enkripsi AES-256 & Deteksi AI Otomatis
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* File Picker Zone */}
          <div className="border-2 border-dashed border-slate-300 hover:border-amber-500 rounded-2xl p-5 text-center bg-slate-50/50 transition-colors">
            <input
              type="file"
              id="file-upload"
              onChange={handleFileChange}
              className="hidden"
            />
            <label
              htmlFor="file-upload"
              className="cursor-pointer flex flex-col items-center justify-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2">
                <FileText className="w-6 h-6" />
              </div>
              <span className="text-xs sm:text-sm font-bold text-slate-900">
                {file ? file.name : 'Pilih Berkas Dokumen (PDF / Scan)'}
              </span>
              <span className="text-[11px] text-slate-400 mt-1">
                Format: PDF, Word, Excel, Gambar Scan (Maks. 25MB)
              </span>
              {file && (
                <span className="mt-2 text-xs font-bold text-slate-950 bg-amber-200 px-2 py-0.5 rounded-md">
                  {(file.size / 1024 / 1024).toFixed(2)} MB • Berkas Terpilih
                </span>
              )}
            </label>
          </div>

          {/* AI Smart Categorization Banner */}
          <div className="p-3.5 rounded-2xl bg-slate-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm border border-amber-500/30">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-400 text-slate-950 shrink-0 font-bold">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold text-white">Deteksi Kategori Cerdas AI</h4>
                <p className="text-[11px] text-slate-400">
                  Secara otomatis memindai dan mengisi kategori, nomor surat, dan JRA
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleRunAICategorization}
              disabled={isAnalyzingAI}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shrink-0 active:scale-95 transition-all"
            >
              {isAnalyzingAI ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Menganalisis...
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                  Deteksi Kategori AI
                </>
              )}
            </button>
          </div>

          {/* AI Result Card */}
          {aiResult && (
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-300 text-xs space-y-1.5 animate-in fade-in">
              <div className="flex items-center justify-between font-bold text-amber-950">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Rekomendasi AI Diterapkan ({aiResult.confidence}%)
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-950 px-2 py-0.5 rounded-full font-extrabold">
                  TERISI OTOMATIS
                </span>
              </div>
              <p className="text-slate-800 text-[11px]">{aiResult.aiReasoning}</p>
            </div>
          )}

          {/* Form Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 mb-1">
                Judul Dokumen / Nama Berkas <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Contoh: Surat Keputusan Kuota Haji 1447H atau SK Pangkat"
                required
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Nomor Surat / Dokumen
              </label>
              <input
                type="text"
                value={docNumber}
                onChange={(e) => setDocNumber(e.target.value)}
                placeholder="Contoh: B-342/KEMEN.HAJI/SET/04/2026"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Kategori Dokumen Kementerian Haji
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ArchiveCategory)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900 font-medium"
              >
                <option value="Regulasi & Kebijakan Haji">Regulasi & Kebijakan Haji (KMHU)</option>
                <option value="Kepegawaian & Petugas Haji">Kepegawaian & Petugas Haji (PPIH)</option>
                <option value="Operasional Kuota & Paspor Jemaah">Operasional Kuota & Paspor Jemaah</option>
                <option value="Layanan Akomodasi & Masyair">Layanan Akomodasi & Masyair (Hotel/Katering)</option>
                <option value="Keuangan & BPIH">Keuangan & BPIH (Anggaran/Audit)</option>
                <option value="Kerjasama Bilateral & Syarikah">Kerjasama Bilateral & Syarikah (KSA)</option>
                <option value="Surat Dinas & Disposisi">Surat Dinas & Disposisi</option>
                <option value="Umum & Publikasi">Umum & Publikasi</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Tingkat Keamanan Dokumen
              </label>
              <select
                value={securityLevel}
                onChange={(e) => {
                  const lvl = e.target.value as SecurityLevel;
                  setSecurityLevel(lvl);
                  if (lvl === 'Rahasia' || lvl === 'Sangat Rahasia') {
                    setIsEncrypted(true);
                  }
                }}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900 font-medium"
              >
                <option value="Publik">Publik (Terbuka untuk umum)</option>
                <option value="Terbatas">Terbatas (Pegawai Kementerian Haji)</option>
                <option value="Rahasia">Rahasia (Perlu Enkripsi Kripto AES-256)</option>
                <option value="Sangat Rahasia">Sangat Rahasia (Khusus Pejabat / Diplomatik)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Subkategori Spesifik
              </label>
              <input
                type="text"
                value={subCategory}
                onChange={(e) => setSubCategory(e.target.value)}
                placeholder="Contoh: Kontrak Sewa Hotel Makkah, SK Penugasan Petugas"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
              />
            </div>

            {/* Is Personnel File Checkbox */}
            <div className="sm:col-span-2 p-3 rounded-2xl bg-slate-100 border border-slate-200">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPersonnelFile}
                  onChange={(e) => setIsPersonnelFile(e.target.checked)}
                  className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                />
                <span className="font-bold text-xs text-slate-950">
                  Tandai sebagai "Berkas Kepegawaian Saya / Dossier Pegawai"
                </span>
              </label>

              {isPersonnelFile && (
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block font-bold text-[11px] text-slate-700 mb-1">
                      Jenis Berkas Kepegawaian
                    </label>
                    <select
                      value={personnelType}
                      onChange={(e) => setPersonnelType(e.target.value as PersonnelType)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-800"
                    >
                      <option value="SK_KENAIKAN_PANGKAT">SK Kenaikan Pangkat</option>
                      <option value="SERTIFIKAT_PPIH">Sertifikat Bimtek PPIH Arab Saudi</option>
                      <option value="PASPOR_DINAS">Paspor Dinas & Visa Haji Petugas</option>
                      <option value="SKP_KINERJA">Sasaran Kinerja Pegawai (SKP)</option>
                      <option value="SK_PNS">SK Pengangkatan CPNS/PNS</option>
                      <option value="IJAZAH">Ijazah & Sertifikasi Keahlian</option>
                      <option value="SURAT_TUGAS_ARAB_SAUDI">Surat Tugas Operasional Saudi</option>
                      <option value="LAINNYA">Berkas Kepegawaian Lainnya</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-[11px] text-slate-700 mb-1">
                      NIP Pegawai Pemilik
                    </label>
                    <input
                      type="text"
                      value={personnelOwnerNip}
                      onChange={(e) => setPersonnelOwnerNip(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono text-slate-800"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Summary */}
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 mb-1">
                Ringkasan Dokumen
              </label>
              <textarea
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                rows={2}
                placeholder="Rangkuman singkat isi dokumen untuk mempermudah pencarian..."
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
              />
            </div>
          </div>

          {/* Encryption Option */}
          <div className="p-3.5 rounded-2xl bg-amber-50/60 border border-amber-300 flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isEncrypted}
                onChange={(e) => setIsEncrypted(e.target.checked)}
                className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
              />
              <span className="font-bold text-xs text-slate-950 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-700" />
                Aktifkan Enkripsi AES-256 untuk Kerahasiaan Berkas
              </span>
            </label>
            <span className="text-[10px] font-bold text-amber-950 bg-amber-200 px-2 py-0.5 rounded-full">
              TERENKRIPSI AMAN
            </span>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs sm:text-sm font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-md active:scale-95 transition-all"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 text-amber-400" />
                  Simpan Berkas
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
