import React, { useState, useMemo } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { ActionType } from '../types/archive';
import {
  History,
  Download,
  Search,
  Filter,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Lock,
  Eye,
  Upload,
  UserCheck,
  RefreshCw,
} from 'lucide-react';

export const AuditLogView: React.FC = () => {
  const { logs, exportLogsToCSV } = useArchive();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedAction, setSelectedAction] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      if (selectedAction !== 'ALL' && log.action !== selectedAction) {
        return false;
      }
      if (selectedStatus !== 'ALL' && log.status !== selectedStatus) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchUser = log.user.name.toLowerCase().includes(q);
        const matchNip = log.user.nip.includes(q);
        const matchTitle = (log.targetTitle || '').toLowerCase().includes(q);
        const matchDetails = log.details.toLowerCase().includes(q);
        const matchHash = log.hash.toLowerCase().includes(q);

        if (!matchUser && !matchNip && !matchTitle && !matchDetails && !matchHash) {
          return false;
        }
      }
      return true;
    });
  }, [logs, selectedAction, selectedStatus, searchQuery]);

  const getStatusBadge = (status: 'SUCCESS' | 'WARNING' | 'DENIED') => {
    switch (status) {
      case 'SUCCESS':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200">
            <CheckCircle className="w-3 h-3 text-emerald-700" /> BERHASIL
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-700" /> PERINGATAN
          </span>
        );
      case 'DENIED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded-full border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-700" /> DITOLAK
          </span>
        );
    }
  };

  const getActionBadgeColor = (action: ActionType) => {
    switch (action) {
      case 'ENCRYPT':
      case 'DECRYPT':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'UPLOAD':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'APPROVE':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'REJECT':
      case 'DELETE':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'GDRIVE_SYNC':
      case 'BACKUP':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header and Export Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-extrabold text-slate-900 tracking-tight">
              Log Audit Keamanan & Jejak Aktivitas Pengguna
            </h2>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
              TAMPER-EVIDENT
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan setiap akses dokumen, enkripsi, dekripsi, perubahan status, dan sinkronisasi untuk audit internal & eksternal
          </p>
        </div>

        <button
          onClick={exportLogsToCSV}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-sm transition-all"
        >
          <Download className="w-4 h-4 text-amber-400" />
          Ekspor Log Audit (.CSV)
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari dalam log (Nama pengguna, NIP, ID Dokumen, Hash audit...)"
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-medium"
            >
              <option value="ALL">Semua Aksi</option>
              <option value="UPLOAD">UPLOAD (Unggah)</option>
              <option value="ENCRYPT">ENCRYPT (Enkripsi)</option>
              <option value="DECRYPT">DECRYPT (Dekripsi)</option>
              <option value="APPROVE">APPROVE (Persetujuan)</option>
              <option value="BACKUP">BACKUP (Pencadangan)</option>
              <option value="GDRIVE_SYNC">GDRIVE_SYNC (Sinkron)</option>
              <option value="DELETE">DELETE (Hapus)</option>
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-medium"
            >
              <option value="ALL">Semua Status</option>
              <option value="SUCCESS">BERHASIL</option>
              <option value="WARNING">PERINGATAN</option>
              <option value="DENIED">DITOLAK</option>
            </select>
          </div>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-4">Waktu (WIB)</th>
                <th className="py-3.5 px-3">Pengguna & NIP</th>
                <th className="py-3.5 px-3">Aksi</th>
                <th className="py-3.5 px-3">Dokumen Sasaran</th>
                <th className="py-3.5 px-3">Status</th>
                <th className="py-3.5 px-3">IP & Perangkat</th>
                <th className="py-3.5 px-4 text-right">Hash Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  {/* Timestamp */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="font-bold text-slate-900">
                      {new Date(log.timestamp).toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </span>
                    <p className="text-[10px] text-slate-400">
                      {new Date(log.timestamp).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </p>
                  </td>

                  {/* User */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span className="font-bold text-slate-900">{log.user.name.split(',')[0]}</span>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="font-mono text-[10px] text-slate-400">NIP: {log.user.nip}</span>
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                        {log.user.role}
                      </span>
                    </div>
                  </td>

                  {/* Action */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${getActionBadgeColor(
                        log.action
                      )}`}
                    >
                      {log.action}
                    </span>
                  </td>

                  {/* Target Document & Details */}
                  <td className="py-3.5 px-3 max-w-xs">
                    <p className="font-semibold text-slate-800 truncate">
                      {log.targetTitle || '-'}
                    </p>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{log.details}</p>
                  </td>

                  {/* Status */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    {getStatusBadge(log.status)}
                  </td>

                  {/* IP & Location */}
                  <td className="py-3.5 px-3 whitespace-nowrap text-[11px] text-slate-500">
                    <p className="font-mono text-slate-700">{log.ipAddress}</p>
                    <p className="text-[10px] text-slate-400 truncate max-w-[120px]">{log.device}</p>
                  </td>

                  {/* Audit Hash */}
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <span className="font-mono text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200">
                      {log.hash}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
