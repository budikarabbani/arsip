import React from 'react';
import {
  X,
  Globe,
  CheckCircle2,
  Server,
  Cloud,
  Laptop,
  Copy,
  ExternalLink,
  ShieldCheck,
  Zap,
  HelpCircle,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface FreePublishGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FreePublishGuideModal: React.FC<FreePublishGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const currentSharedUrl = window.location.origin;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Tautan / perintah berhasil disalin ke papan klip!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-slate-800">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200">
              <Globe className="w-6 h-6 text-amber-700" />
            </div>
            <div>
              <span className="text-[10px] font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-full uppercase tracking-wider">
                100% BEBAS BIAYA • RP 0
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-950 mt-1">
                Panduan Menjalankan Aplikasi Tanpa Bayar $300 Google Cloud
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-5 space-y-5 text-xs text-slate-700 leading-relaxed">
          {/* Clarification about the "$300" Google Prompt */}
          <div className="p-4 rounded-2xl bg-slate-950 text-white border border-amber-500/30 space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-xs">
                !
              </span>
              <h4 className="font-extrabold text-white text-xs sm:text-sm">
                Apakah Perlu Bayar $300 ke Google Cloud? Jawabannya: TIDAK PERLU SAMA SEKALI!
              </h4>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Notifikasi atau tulisan <strong>"$300 Free Trial Credit"</strong> di Google Cloud hanyalah promosi voucher uji coba bagi perusahaan enterprise jika ingin mencoba produk komputasi skala raksasa.
              Aplikasi <strong>BUDIKA ARSIP</strong> ini <strong>sama sekali tidak memerlukan langganan berbayar tersebut</strong>.
            </p>
          </div>

          {/* 3 Free Ways to Run Forever */}
          <div className="space-y-4">
            <h4 className="font-black text-slate-950 text-sm">
              3 Cara Menjalankan Aplikasi Ini 100% Gratis Selamanya:
            </h4>

            {/* Option 1: AI Studio Shared URL (Already Live) */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                  <Zap className="w-4 h-4 text-amber-500" />
                  Opsi 1 — Langsung Pakai Tautan AI Studio yang Sudah Aktif (Paling Mudah)
                </span>
                <span className="text-[10px] font-black text-slate-950 bg-amber-300 px-2 py-0.5 rounded-md">
                  SUDAH AKTIF
                </span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Aplikasi ini sudah online di cloud Google AI Studio secara gratis. Anda tidak perlu setup server apapun. Cukup salin tautan berikut dan bagikan ke rekan kantor untuk dibuka langsung di HP atau laptop:
              </p>
              <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-300 font-mono text-[11px] text-slate-900 break-all font-bold">
                <span className="truncate flex-1">{currentSharedUrl}</span>
                <button
                  onClick={() => handleCopy(currentSharedUrl)}
                  className="px-2.5 py-1 text-xs font-bold bg-slate-950 hover:bg-black text-amber-300 rounded-lg shrink-0 flex items-center gap-1 transition-all"
                >
                  <Copy className="w-3.5 h-3.5" /> Salin URL
                </button>
              </div>
              <p className="text-[10px] text-slate-500">
                Tips: Pada browser ponsel (Chrome / Safari), klik menu titik tiga lalu pilih <strong>"Tambahkan ke Layar Utama" (Add to Home Screen)</strong> agar aplikasi terpasang seperti aplikasi instansi resmi.
              </p>
            </div>

            {/* Option 2: Free Hosting on Vercel or Render */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                  <Cloud className="w-4 h-4 text-amber-600" />
                  Opsi 2 — Hosting Gratis di Vercel, Netlify, atau Render (Dukungan Domain Sendiri)
                </span>
                <span className="text-[10px] font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded-md">
                  GRATIS SELAMANYA
                </span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Jika Anda ingin memasang nama domain kantor sendiri (misal: <code>arsip.haji.go.id</code> atau <code>budika-arsip.vercel.app</code>) tanpa bayar sepeserpun:
              </p>
              <ol className="list-decimal pl-4 space-y-1 text-[11px] text-slate-600">
                <li>Unduh kode aplikasi ini dari menu ekspor/GitHub (gratis).</li>
                <li>Daftar akun di <strong>Vercel.com</strong> atau <strong>Render.com</strong> (pilih paket <em>Hobby / Free Plan</em> — Rp 0 selamanya tanpa perlu kartu kredit).</li>
                <li>Hubungkan repositori GitHub Anda dan klik <strong>Deploy</strong>.</li>
                <li>Website kearsipan Anda langsung live 24/7 di seluruh dunia dengan sertifikat SSL HTTPS resmi.</li>
              </ol>
            </div>

            {/* Option 3: Local Office Computer (Intranet LAN) */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                <Laptop className="w-4 h-4 text-slate-800" />
                Opsi 3 — Server Lokal / Komputer Kantor Kementerian (Offline Intranet LAN)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Aplikasi ini dapat dijalankan langsung di satu komputer server/laptop kantor kementerian secara lokal:
              </p>
              <div className="bg-slate-950 text-amber-300 p-2.5 rounded-xl font-mono text-[10px] space-y-1 border border-amber-500/20">
                <p>npm run build</p>
                <p>npm run start</p>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Seluruh pegawai di ruangan kantor yang terhubung ke jaringan Wi-Fi/LAN kantor dapat membuka alamat IP komputer tersebut (misal: <code>http://192.168.1.50:3000</code>) tanpa perlu koneksi internet luar dan tanpa biaya server sama sekali.
              </p>
            </div>
          </div>

          {/* Guarantee Box */}
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 text-[11px] space-y-1">
            <span className="font-extrabold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-600" /> Jaminan Bebas Biaya Kearsipan:
            </span>
            <p className="leading-relaxed">
              Google Drive (15 GB gratis), Firebase Auth, dan model AI Gemini Flash di aplikasi ini berjalan di atas kuota gratis (Free Tier). Anda <strong>tidak akan pernah ditagih biaya oleh Google Cloud</strong> selama Anda tidak mengaktifkan penagihan berbayar.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <span className="text-[11px] text-slate-400">
            Kementerian Haji dan Umrah Republik Indonesia
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-sm transition-all"
          >
            Mengerti, Tutup Panduan
          </button>
        </div>
      </div>
    </div>
  );
};
