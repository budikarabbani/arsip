import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { UserRole } from '../types/archive';
import {
  ShieldCheck,
  Search,
  Bell,
  CloudCheck,
  CloudOff,
  ChevronDown,
  RefreshCw,
  Building2,
  CheckCircle2,
  Upload,
  Globe,
  Users,
  UserPlus,
} from 'lucide-react';
import { FreePublishGuideModal } from './FreePublishGuideModal';

export const Header: React.FC = () => {
  const {
    currentUser,
    users,
    switchUser,
    isGoogleConnected,
    connectGoogleDrive,
    disconnectGoogleDrive,
    isSyncingGDrive,
    syncAllToDrive,
    searchQuery,
    setSearchQuery,
    notifications,
    markAllNotifsRead,
    markNotifAsRead,
    setIsUploadModalOpen,
    setActiveTab,
  } = useArchive();

  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);
  const [isPublishGuideOpen, setIsPublishGuideOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.read);

  const handleConnectGoogle = async () => {
    setIsConnectingDrive(true);
    await connectGoogleDrive();
    setIsConnectingDrive(false);
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'bg-amber-100 text-amber-900 border-amber-300 font-extrabold';
      case 'ARSIPARIS':
        return 'bg-slate-100 text-slate-800 border-slate-300 font-bold';
      case 'PEJABAT_VERIFIKATOR':
        return 'bg-stone-200 text-stone-900 border-stone-400 font-bold';
      case 'PEGAWAI':
        return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'AUDITOR':
        return 'bg-red-100 text-red-900 border-red-300 font-bold';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950 text-white border-b border-amber-500/20 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo & Title: BUDIKA ARSIP - Kementerian Haji dan Umrah */}
          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-md ring-2 ring-amber-400/40 group-hover:scale-105 transition-transform">
              <span className="text-xl font-black tracking-tighter">B</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg text-white tracking-tight">
                  BUDIKA <span className="text-amber-400">ARSIP</span>
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-bold bg-amber-400/15 text-amber-300 px-2 py-0.5 rounded-full border border-amber-400/30">
                  <ShieldCheck className="w-3 h-3 text-amber-400" /> AES-256
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden md:block">
                Kementerian Haji dan Umrah Republik Indonesia
              </p>
            </div>
          </div>

          {/* Global Search Bar */}
          <div className="flex-1 max-w-md mx-4 hidden lg:block">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4 text-slate-500" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari berkas, nomor surat, NIP, pegawai, regulasi..."
                className="w-full pl-10 pr-10 py-2 text-xs sm:text-sm bg-slate-900/90 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-400 focus:bg-slate-900 transition-all text-white placeholder:text-slate-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Action Center & Profile */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Admin Panel Quick Access Button */}
            <button
              onClick={() => setActiveTab('admin_users')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-sm active:scale-95 transition-all"
              title="Panel Admin & Pendaftaran Pengguna Berdasarkan Email"
            >
              <Users className="w-3.5 h-3.5 text-slate-950" />
              <span className="hidden sm:inline">Panel Admin</span>
            </button>

            {/* Quick Upload Button */}
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-white hover:bg-slate-100 text-slate-950 shadow-sm active:scale-95 transition-all"
            >
              <Upload className="w-3.5 h-3.5 text-slate-950" />
              <span className="hidden sm:inline">Unggah</span>
            </button>

            {/* Free Hosting Guide Button */}
            <button
              onClick={() => setIsPublishGuideOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-all shadow-xs"
              title="Panduan Menjalankan 100% Bebas Biaya (Tanpa Bayar $300)"
            >
              <Globe className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden lg:inline">Gratis $0</span>
            </button>

            {/* Google Drive Status Indicator */}
            {isGoogleConnected ? (
              <button
                onClick={() => syncAllToDrive()}
                disabled={isSyncingGDrive}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 text-amber-300 text-xs font-medium border border-amber-500/30 hover:bg-slate-800 transition-colors"
                title="Google Drive Terhubung. Klik untuk sinkronisasi massal"
              >
                <CloudCheck className="w-4 h-4 text-amber-400" />
                <span className="hidden xl:inline text-xs font-semibold">Drive Aktif</span>
                {isSyncingGDrive && <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />}
              </button>
            ) : (
              <button
                onClick={handleConnectGoogle}
                disabled={isConnectingDrive}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
                title="Hubungkan Google Drive untuk pencadangan otomatis"
              >
                <CloudOff className="w-4 h-4 text-slate-400" />
                <span className="hidden xl:inline">Drive</span>
              </button>
            )}

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setIsNotifDropdownOpen(!isNotifDropdownOpen)}
                className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-900 rounded-xl transition-colors"
                title="Pemberitahuan Sistem"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifs.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-400 rounded-full ring-2 ring-slate-950 animate-pulse" />
                )}
              </button>

              {/* Notification Dropdown */}
              {isNotifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <span className="font-extrabold text-sm text-slate-900">Pemberitahuan</span>
                      {unreadNotifs.length > 0 && (
                        <span className="text-[11px] bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 rounded-full">
                          {unreadNotifs.length}
                        </span>
                      )}
                    </div>
                    {unreadNotifs.length > 0 && (
                      <button
                        onClick={markAllNotifsRead}
                        className="text-xs text-amber-800 hover:text-amber-950 font-bold"
                      >
                        Tandai terbaca
                      </button>
                    )}
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="py-6 text-center text-xs text-slate-400">
                        Tidak ada pemberitahuan baru
                      </div>
                    ) : (
                      notifications.slice(0, 6).map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => {
                            markNotifAsRead(notif.id);
                            setIsNotifDropdownOpen(false);
                            if (notif.docId) {
                              setActiveTab('archives');
                            }
                          }}
                          className={`p-3 text-left hover:bg-slate-50 cursor-pointer transition-colors ${
                            !notif.read ? 'bg-amber-50/40' : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-xs font-bold text-slate-900">{notif.title}</p>
                            <span className="text-[10px] text-slate-400 whitespace-nowrap">
                              {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5 line-clamp-2">{notif.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Profile & Switcher Menu */}
            <div className="relative">
              <button
                onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-700 bg-slate-900 hover:border-amber-400 transition-all text-left"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-lg object-cover ring-1 ring-amber-400/40"
                />
                <div className="hidden sm:block">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-white leading-tight truncate max-w-[120px]">
                      {currentUser.name.split(' ')[0]}
                    </p>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                  <span
                    className={`inline-block text-[9px] font-extrabold px-1.5 py-0.2 rounded border ${getRoleBadgeColor(
                      currentUser.role
                    )}`}
                  >
                    {currentUser.role.replace('_', ' ')}
                  </span>
                </div>
              </button>

              {/* User Switcher Dropdown */}
              {isUserDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 p-2 z-50">
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-[11px] text-slate-400">Akun Aktif Saat Ini</p>
                    <p className="text-xs font-extrabold text-slate-900 mt-0.5">{currentUser.name}</p>
                    <p className="text-[11px] text-amber-700 font-mono">{currentUser.email}</p>
                    <p className="text-[10px] text-slate-500 font-mono">NIP: {currentUser.nip}</p>
                  </div>

                  <div className="pt-2">
                    <div className="flex items-center justify-between px-3 mb-1">
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        Ganti Akun Pengguna
                      </p>
                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          setActiveTab('admin_users');
                        }}
                        className="text-[11px] font-bold text-amber-700 hover:text-amber-900"
                      >
                        + Tambah
                      </button>
                    </div>

                    <div className="space-y-1 max-h-56 overflow-y-auto">
                      {users.map((u) => (
                        <button
                          key={u.id}
                          onClick={() => {
                            switchUser(u.id);
                            setIsUserDropdownOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left text-xs transition-colors ${
                            currentUser.id === u.id
                              ? 'bg-amber-50 text-amber-950 font-bold'
                              : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-6 h-6 rounded-md object-cover shrink-0"
                          />
                          <div className="flex-1 truncate">
                            <p className="truncate font-semibold">{u.name}</p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">{u.email}</p>
                          </div>
                          {currentUser.id === u.id && (
                            <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="pt-2 mt-2 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          setActiveTab('admin_users');
                        }}
                        className="w-full py-2 px-3 text-xs font-bold rounded-xl bg-slate-900 hover:bg-black text-amber-300 flex items-center justify-center gap-1.5"
                      >
                        <UserPlus className="w-3.5 h-3.5 text-amber-300" />
                        Buka Panel Admin & Pendaftaran
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <FreePublishGuideModal
        isOpen={isPublishGuideOpen}
        onClose={() => setIsPublishGuideOpen(false)}
      />
    </header>
  );
};
