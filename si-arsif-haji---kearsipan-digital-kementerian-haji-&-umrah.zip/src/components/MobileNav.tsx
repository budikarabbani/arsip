import React from 'react';
import { useArchive } from '../context/ArchiveContext';
import {
  LayoutDashboard,
  FolderArchive,
  UserCheck,
  Lock,
  History,
  CloudCog,
  Upload,
  Users,
} from 'lucide-react';

export const MobileNav: React.FC = () => {
  const { activeTab, setActiveTab, setIsUploadModalOpen } = useArchive();

  const tabs = [
    { id: 'dashboard', label: 'Dasbor', icon: LayoutDashboard },
    { id: 'archives', label: 'Arsip', icon: FolderArchive },
    { id: 'upload-action', label: 'Unggah', icon: Upload, isAction: true },
    { id: 'admin_users', label: 'Admin', icon: Users },
    { id: 'personnel', label: 'Pegawai', icon: UserCheck },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 py-1 safe-area-pb">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          if (tab.isAction) {
            return (
              <button
                key={tab.id}
                onClick={() => setIsUploadModalOpen(true)}
                className="flex flex-col items-center justify-center p-1 -mt-5"
              >
                <div className="w-12 h-12 rounded-full bg-slate-950 text-amber-400 shadow-lg flex items-center justify-center ring-4 ring-white active:scale-95 transition-all border border-amber-500/30">
                  <Upload className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-slate-950 mt-1">Unggah</span>
              </button>
            );
          }

          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-colors ${
                isActive ? 'text-slate-950 font-black' : 'text-slate-400 hover:text-slate-700'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-amber-600' : ''}`} />
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
