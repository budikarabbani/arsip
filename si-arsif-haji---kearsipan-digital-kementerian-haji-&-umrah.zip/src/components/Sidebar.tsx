import React from 'react';
import { useArchive } from '../context/ArchiveContext';
import {
  LayoutDashboard,
  FolderArchive,
  UserCheck,
  Lock,
  History,
  CloudCog,
  Users,
  PlusCircle,
  ShieldCheck,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, documents, users, setIsUploadModalOpen } = useArchive();

  const encryptedCount = documents.filter((d) => d.isEncrypted).length;
  const myPersonnelCount = documents.filter((d) => d.isPersonnelFile).length;
  const pendingCount = documents.filter((d) => d.status === 'Menunggu Verifikasi').length;

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dasbor Statistik',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'archives',
      label: 'Bank Arsip Digital',
      icon: FolderArchive,
      badge: pendingCount > 0 ? `${pendingCount} perlu cek` : null,
      badgeColor: 'bg-amber-100 text-amber-900 border border-amber-300',
    },
    {
      id: 'personnel',
      label: 'Berkas Kepegawaian',
      icon: UserCheck,
      badge: `${myPersonnelCount}`,
      badgeColor: 'bg-slate-100 text-slate-800 border border-slate-300',
    },
    {
      id: 'admin_users',
      label: 'Panel Admin & Pengguna',
      icon: Users,
      badge: `${users.length} user`,
      badgeColor: 'bg-amber-100 text-amber-950 font-extrabold border border-amber-300',
    },
    {
      id: 'vault',
      label: 'Brankas Terenkripsi',
      icon: Lock,
      badge: `${encryptedCount}`,
      badgeColor: 'bg-stone-100 text-stone-800',
    },
    {
      id: 'audit',
      label: 'Log Audit Keamanan',
      icon: History,
      badge: null,
    },
    {
      id: 'backup',
      label: 'Google Drive & Cadangan',
      icon: CloudCog,
      badge: null,
    },
  ];

  return (
    <aside className="w-64 shrink-0 hidden md:block bg-white border-r border-slate-200 p-4 min-h-[calc(100vh-4.5rem)]">
      {/* Upload Callout Card - Gold & Black theme */}
      <div className="mb-6 p-4 rounded-2xl bg-gradient-to-br from-slate-950 via-zinc-900 to-stone-950 text-white shadow-md relative overflow-hidden border border-amber-500/20">
        <div className="relative z-10">
          <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider">
            BUDIKA ARSIP DIGITAL
          </span>
          <h4 className="text-xs font-bold text-white mt-1 leading-snug">
            Kementerian Haji dan Umrah Republik Indonesia
          </h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Enkripsi AES-256 otomatis & deteksi kategori AI cerdas.
          </p>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="mt-3 w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 active:scale-95 transition-all shadow-sm"
          >
            <PlusCircle className="w-4 h-4 text-slate-950" />
            Unggah Berkas Baru
          </button>
        </div>
        <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
      </div>

      {/* Navigation List */}
      <div className="space-y-1">
        <p className="text-[10px] font-bold text-slate-400 px-3 uppercase tracking-wider mb-2">
          Menu Utama
        </p>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-slate-950 text-amber-300 shadow-sm border border-amber-500/30'
                  : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 ${
                    isActive ? 'text-amber-400' : 'text-slate-500'
                  }`}
                />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isActive ? 'bg-amber-400/20 text-amber-300' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* System Status info at bottom of sidebar */}
      <div className="mt-8 pt-4 border-t border-slate-200">
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Standar Kripto</span>
            <span className="font-bold text-slate-900">AES-GCM-256</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Penyimpanan</span>
            <span className="font-bold text-amber-800">Google Drive API</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Model AI</span>
            <span className="font-bold text-slate-900">Gemini 3.8 Flash</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
