import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { DocumentStatus } from '../types/archive';
import { OfficialDocumentSheet } from './OfficialDocumentSheet';
import {
  X,
  Lock,
  Unlock,
  CloudCheck,
  CloudOff,
  Share2,
  CheckCircle2,
  Clock,
  ShieldCheck,
  FileText,
  Mail,
  MessageCircle,
  Copy,
  ExternalLink,
  Trash2,
  Sparkles,
  Printer,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Download,
  Eye,
  SlidersHorizontal,
  Check,
} from 'lucide-react';

export const DocumentDetailModal: React.FC = () => {
  const {
    selectedDocumentForDetail,
    setSelectedDocumentForDetail,
    updateDocumentStatus,
    deleteDocument,
    decryptDoc,
    currentUser,
  } = useArchive();

  const doc = selectedDocumentForDetail;

  const [activeModalTab, setActiveModalTab] = useState<'preview' | 'details'>('preview');
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const [passphraseInput, setPassphraseInput] = useState<string>('');
  const [decryptedText, setDecryptedText] = useState<string | null>(null);
  const [decryptError, setDecryptError] = useState<string | null>(null);
  const [isDecrypting, setIsDecrypting] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Status & disposition
  const [dispositionNotes, setDispositionNotes] = useState<string>('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState<boolean>(false);

  // Notification Modals
  const [showWhatsAppModal, setShowWhatsAppModal] = useState<boolean>(false);
  const [showEmailModal, setShowEmailModal] = useState<boolean>(false);
  const [targetPhone, setTargetPhone] = useState<string>('081288990011');
  const [targetEmail, setTargetEmail] = useState<string>(doc?.ownerEmail || 'pegawai@haji.go.id');
  const [copiedNotif, setCopiedNotif] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<boolean>(false);

  if (!doc) return null;

  const handleClose = () => {
    setSelectedDocumentForDetail(null);
    setDecryptedText(null);
    setDecryptError(null);
    setPassphraseInput('');
    setIsFullscreen(false);
    setZoomLevel(100);
    setActiveModalTab('preview');
  };

  const handleDecrypt = async () => {
    setIsDecrypting(true);
    setDecryptError(null);

    const key = passphraseInput.trim() || 'BUDIKA-ARSIF-HAJI-SECURE-2026';
    const res = await decryptDoc(doc.id, key);

    if (res.success && res.content) {
      setDecryptedText(res.content);
    } else {
      setDecryptError(res.error || 'Kata sandi / Kunci enkripsi tidak valid.');
    }
    setIsDecrypting(false);
  };

  const handleStatusChange = async (newStatus: DocumentStatus) => {
    setIsUpdatingStatus(true);
    await updateDocumentStatus(doc.id, newStatus, dispositionNotes);
    setIsUpdatingStatus(false);
  };

  const handleDeleteThisDoc = async () => {
    const confirmed = window.confirm(
      `HAPUS DOKUMEN?\n\nJudul: "${doc.title}"\nNomor: ${doc.docNumber}\n\nApakah Anda yakin ingin menghapus berkas ini secara permanen dari sistem BUDIKA ARSIP?`
    );
    if (confirmed) {
      setIsDeleting(true);
      await deleteDocument(doc.id);
      setIsDeleting(false);
      handleClose();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCopy = () => {
    const content = decryptedText || doc.fileData || doc.summary;
    const blob = new Blob([
      `KEMENTERIAN HAJI DAN UMRAH REPUBLIK INDONESIA\n` +
      `BUDIKA ARSIP - DOKUMEN RESMI\n` +
      `==================================================\n` +
      `Nomor Dokumen : ${doc.docNumber}\n` +
      `Judul Naskah  : ${doc.title}\n` +
      `Kategori      : ${doc.category} (${doc.subCategory})\n` +
      `Sifat         : ${doc.securityLevel}\n` +
      `Tanggal       : ${new Date(doc.uploadDate).toLocaleDateString('id-ID')}\n` +
      `Pengunggah    : ${doc.ownerName} (NIP. ${doc.ownerNip})\n` +
      `Integritas    : SHA-256 ${doc.sha256Hash}\n` +
      `==================================================\n\n` +
      `ISI DOKUMEN:\n\n${content}`
    ], { type: 'text/plain;charset=utf-8' });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.docNumber.replace(/[/\\?%*:|"<>]/g, '_')}_Naskah_Dinas.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyDocumentText = () => {
    const content = decryptedText || doc.fileData || doc.summary;
    navigator.clipboard.writeText(content);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Pre-formatted WhatsApp notification message
  const generateWhatsAppMessage = () => {
    return `*KEMENTERIAN HAJI DAN UMRAH RI*%0A*BUDIKA ARSIP - Sistem Kearsipan Digital*%0A%0AYth. Rekan Petugas/Pegawai,%0ABerikut pemberitahuan status dokumen kearsipan Anda:%0A%0A*No. Dokumen:* ${doc.docNumber}%0A*Judul:* ${doc.title}%0A*Kategori:* ${doc.category}%0A*Status Saat Ini:* *${doc.status.toUpperCase()}*%0A*Verifikator:* ${doc.lastVerifiedBy || currentUser.name}%0A*Catatan Disposisi:* ${dispositionNotes || doc.dispositionNotes || 'Dokumen telah tercatat di bank arsip.'}%0A%0ASilakan akses portal BUDIKA ARSIP untuk pratinjau dokumen terenkripsi. Terima kasih.`;
  };

  const handleOpenWhatsApp = () => {
    const cleanPhone = targetPhone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone;
    const url = `https://wa.me/${phoneWithCountry}?text=${generateWhatsAppMessage()}`;
    window.open(url, '_blank');
  };

  // Pre-formatted Email notification
  const generateEmailSubject = () => {
    return `[BUDIKA ARSIP] Pembaruan Status Dokumen: ${doc.docNumber} - ${doc.status}`;
  };

  const generateEmailBody = () => {
    return `Kepada Yth. Pegawai / Petugas Terkait,

Melalui surat elektronik ini kami memberitahukan bahwa berkas kearsipan berikut telah diperbarui status pemrosesannya:

Nomor Berkas : ${doc.docNumber}
Judul Berkas : ${doc.title}
Kategori     : ${doc.category} (${doc.subCategory})
Tingkat Keamanan : ${doc.securityLevel}
Status       : ${doc.status}
Verifikator  : ${doc.lastVerifiedBy || currentUser.name}
Catatan      : ${dispositionNotes || doc.dispositionNotes || 'Tidak ada catatan khusus.'}
Hash SHA-256 : ${doc.sha256Hash}

Dokumen dapat diakses dan diverifikasi melalui aplikasi BUDIKA ARSIP Kementerian Haji dan Umrah Republik Indonesia.

Hormat kami,
Biro Umum & Kearsipan
Kementerian Haji dan Umrah Republik Indonesia`;
  };

  const handleSendEmail = () => {
    const subject = encodeURIComponent(generateEmailSubject());
    const body = encodeURIComponent(generateEmailBody());
    window.open(`mailto:${targetEmail}?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div
        className={`bg-white rounded-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col transition-all duration-200 ${
          isFullscreen
            ? 'fixed inset-2 sm:inset-4 max-w-none max-h-none h-[calc(100vh-2rem)]'
            : 'max-w-4xl max-h-[92vh]'
        }`}
      >
        {/* Header Bar */}
        <div className="bg-slate-950 text-white p-4 sm:p-5 flex items-center justify-between border-b border-amber-500/20 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
              <Eye className="w-5 h-5 text-slate-950" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] font-bold text-amber-300 bg-amber-400/15 px-2 py-0.5 rounded border border-amber-400/30">
                  {doc.docNumber}
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-200">
                  {doc.category}
                </span>
                {doc.isEncrypted && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                    <Lock className="w-3 h-3 text-amber-400" /> AES-256
                  </span>
                )}
              </div>
              <h2 className="text-xs sm:text-sm font-extrabold text-white truncate mt-1">
                {doc.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 ml-2">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title={isFullscreen ? 'Kecilkan Layar' : 'Layar Penuh'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={handleClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Tutup Jendela"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher & Viewer Toolbar */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex flex-wrap items-center justify-between gap-3 shrink-0">
          {/* Main Tabs */}
          <div className="flex items-center gap-1 bg-slate-200/80 p-1 rounded-2xl">
            <button
              onClick={() => setActiveModalTab('preview')}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeModalTab === 'preview'
                  ? 'bg-slate-950 text-amber-400 shadow-xs'
                  : 'text-slate-700 hover:text-slate-950'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Pratinjau Naskah Resmi (Preview)</span>
            </button>

            <button
              onClick={() => setActiveModalTab('details')}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeModalTab === 'details'
                  ? 'bg-slate-950 text-amber-400 shadow-xs'
                  : 'text-slate-700 hover:text-slate-950'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Rincian Metadata & Disposisi</span>
            </button>
          </div>

          {/* Viewer Toolbar Actions (Visible on Preview tab) */}
          {activeModalTab === 'preview' && (
            <div className="flex items-center gap-1.5 text-xs">
              {/* Zoom Controls */}
              <div className="flex items-center bg-white border border-slate-300 rounded-xl px-1 py-0.5 shadow-2xs">
                <button
                  onClick={() => setZoomLevel((prev) => Math.max(70, prev - 10))}
                  className="p-1.5 text-slate-600 hover:text-slate-950 hover:bg-slate-100 rounded-lg"
                  title="Perkecil (-)"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="font-mono text-[11px] font-bold px-2 text-slate-800">
                  {zoomLevel}%
                </span>
                <button
                  onClick={() => setZoomLevel((prev) => Math.min(150, prev + 10))}
                  className="p-1.5 text-slate-600 hover:text-slate-950 hover:bg-slate-100 rounded-lg"
                  title="Perbesar (+)"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Print Document */}
              <button
                onClick={handlePrint}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold shadow-2xs active:scale-95 transition-all"
                title="Cetak Dokumen Resmi / Simpan sebagai PDF"
              >
                <Printer className="w-3.5 h-3.5 text-slate-700" />
                <span className="hidden sm:inline">Cetak PDF</span>
              </button>

              {/* Copy Document Text */}
              <button
                onClick={handleCopyDocumentText}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold shadow-2xs active:scale-95 transition-all"
                title="Salin Isi Teks Dokumen"
              >
                {copiedText ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-slate-700" />
                )}
                <span className="hidden sm:inline">{copiedText ? 'Tersalin' : 'Salin Teks'}</span>
              </button>

              {/* Download Copy */}
              <button
                onClick={handleDownloadCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold shadow-2xs active:scale-95 transition-all"
                title="Unduh Salinan Dokumen Digital"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Unduh Salinan</span>
              </button>
            </div>
          )}
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100/60">
          {activeModalTab === 'preview' ? (
            /* TAB 1: PREVIEW TAB (Interactive Document Viewer) */
            <div className="space-y-6">
              {/* If Encrypted: Quick Passphrase Bar */}
              {doc.isEncrypted && (
                <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-700 shrink-0" />
                    <div>
                      <span className="font-bold text-amber-950">
                        {decryptedText ? 'Dekripsi Berhasil: Isi naskah dapat dibaca transparan.' : 'Naskah Ini Terenkripsi AES-256'}
                      </span>
                      <p className="text-[11px] text-amber-900/80">
                        {decryptedText ? 'Teks asli ditampilkan pada lembar pratinjau naskah dinas di bawah.' : 'Masukkan kunci enkripsi untuk menampilkan isi naskah asli.'}
                      </p>
                    </div>
                  </div>

                  {!decryptedText ? (
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <input
                        type="password"
                        value={passphraseInput}
                        onChange={(e) => setPassphraseInput(e.target.value)}
                        placeholder="Kunci kementerian..."
                        className="px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-slate-900 w-full sm:w-48"
                      />
                      <button
                        onClick={handleDecrypt}
                        disabled={isDecrypting}
                        className="px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shrink-0 active:scale-95 transition-all"
                      >
                        {isDecrypting ? 'Mendekripsi...' : 'Buka'}
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setDecryptedText(null)}
                      className="px-3 py-1 text-xs font-semibold rounded-xl bg-amber-200 text-amber-950 hover:bg-amber-300 self-start sm:self-auto"
                    >
                      Kunci Kembali
                    </button>
                  )}
                </div>
              )}

              {/* The Official Ministry Letter Sheet */}
              <div className="py-2 overflow-x-auto flex justify-center">
                <OfficialDocumentSheet
                  doc={doc}
                  decryptedText={decryptedText}
                  onDecryptClick={handleDecrypt}
                  isDecrypting={isDecrypting}
                  zoomLevel={zoomLevel}
                />
              </div>

              {/* Quick Status Disposition Below Preview */}
              <div className="p-4 bg-white rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">
                    Alur Status Naskah: <span className="text-amber-800 font-black">{doc.status}</span>
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Verifikator: {doc.lastVerifiedBy || currentUser.name}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleStatusChange('Diarsipkan')}
                    disabled={isUpdatingStatus}
                    className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold text-xs"
                  >
                    ✓ Setujui Arsip
                  </button>
                  <button
                    onClick={() => setShowWhatsAppModal(true)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    Kirim WA
                  </button>
                  <button
                    onClick={() => setShowEmailModal(true)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Kirim Email
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* TAB 2: METADATA & WORKFLOW DETAILS */
            <div className="space-y-5 text-xs text-slate-700">
              {/* Summary Box */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2">
                <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-amber-600" /> Ringkasan Eksekutif Dokumen
                </h4>
                <p className="text-slate-700 text-xs leading-relaxed">{doc.summary}</p>
                {doc.aiReasoning && (
                  <p className="text-[11px] text-amber-950 bg-amber-50 p-2.5 rounded-xl border border-amber-200 flex items-center gap-1.5 font-medium">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <strong>Analisis Cerdas AI:</strong> {doc.aiReasoning}
                  </p>
                )}
              </div>

              {/* Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Tingkat Keamanan:</span>
                  <p className="font-bold text-slate-900 mt-0.5">{doc.securityLevel}</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Status Kearsipan:</span>
                  <p className="font-bold text-slate-900 mt-0.5">{doc.status}</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Masa Retensi JRA:</span>
                  <p className="font-bold text-slate-900 mt-0.5">
                    {doc.retentionYears} Thn ({doc.retentionAction})
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Pengunggah Berkas:</span>
                  <p className="font-bold text-slate-900 mt-0.5">{doc.ownerName}</p>
                  <p className="text-[10px] text-slate-400 font-mono">NIP: {doc.ownerNip}</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Ukuran Berkas:</span>
                  <p className="font-bold text-slate-900 mt-0.5">
                    {(doc.fileSize / 1024 / 1024).toFixed(2)} MB ({doc.fileType.toUpperCase()})
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <span className="text-slate-400 text-[11px]">Penyimpanan Google Drive:</span>
                  <p className="font-bold text-slate-900 mt-0.5 flex items-center gap-1">
                    {doc.gdriveSynced ? (
                      <span className="text-amber-800 flex items-center gap-1 font-bold">
                        <CloudCheck className="w-3.5 h-3.5 text-amber-600" /> Tersinkron
                      </span>
                    ) : (
                      <span className="text-slate-500 flex items-center gap-1">
                        <CloudOff className="w-3.5 h-3.5" /> Belum Sinkron
                      </span>
                    )}
                  </p>
                </div>
              </div>

              {/* Cryptographic Hash Verification Card */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                    Checksum Integritas Dokumen (SHA-256)
                  </span>
                  <span className="text-[10px] text-slate-950 font-black bg-amber-400 px-2 py-0.5 rounded-md">
                    INTEGRITY VERIFIED
                  </span>
                </div>
                <p className="font-mono text-[11px] text-slate-700 break-all bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {doc.sha256Hash}
                </p>
              </div>

              {/* Workflow & Verification Box */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <h4 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-amber-600" />
                  Alur Kerja & Disposisi Verifikasi Dokumen
                </h4>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Catatan Disposisi / Instruksi Pimpinan:
                  </label>
                  <input
                    type="text"
                    value={dispositionNotes}
                    onChange={(e) => setDispositionNotes(e.target.value)}
                    placeholder="Misal: Disetujui untuk diarsipkan secara definitif..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => handleStatusChange('Diarsipkan')}
                    disabled={isUpdatingStatus}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold text-xs transition-colors"
                  >
                    ✓ Setujui & Diarsipkan
                  </button>
                  <button
                    onClick={() => handleStatusChange('Diverifikasi')}
                    disabled={isUpdatingStatus}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition-colors"
                  >
                    Verifikasi Valid
                  </button>
                  <button
                    onClick={() => handleStatusChange('Ditolak')}
                    disabled={isUpdatingStatus}
                    className="px-3.5 py-1.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-900 font-bold text-xs transition-colors"
                  >
                    Tolak / Perlu Revisi
                  </button>
                </div>
              </div>

              {/* Automated Notification Triggers (WhatsApp & Email) */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <h4 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  <Share2 className="w-4 h-4 text-amber-600" />
                  Kirim Notifikasi Otomatis Terkait Dokumen
                </h4>
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => setShowWhatsAppModal(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all active:scale-95"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Kirim via WhatsApp
                  </button>

                  <button
                    onClick={() => setShowEmailModal(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-black text-amber-300 font-bold text-xs shadow-xs transition-all active:scale-95"
                  >
                    <Mail className="w-4 h-4" />
                    Kirim via Email Resmi
                  </button>

                  {doc.gdriveLink && (
                    <a
                      href={doc.gdriveLink}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-amber-700" />
                      Buka di Google Drive
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer with Explicit Delete Button */}
        <div className="bg-white p-4 sm:px-6 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={handleDeleteThisDoc}
            disabled={isDeleting}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Hapus Dokumen</span>
          </button>

          <button
            onClick={handleClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>

      {/* WHATSAPP MODAL POPUP */}
      {showWhatsAppModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2 text-emerald-800 font-bold">
                <MessageCircle className="w-5 h-5 text-emerald-600" />
                <span>Kirim Notifikasi WhatsApp</span>
              </div>
              <button onClick={() => setShowWhatsAppModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <label className="block font-bold text-slate-700">Nomor WhatsApp Tujuan:</label>
              <input
                type="text"
                value={targetPhone}
                onChange={(e) => setTargetPhone(e.target.value)}
                placeholder="0812xxxxxxxx"
                className="w-full px-3 py-2 text-xs border rounded-xl"
              />
            </div>

            <button
              onClick={handleOpenWhatsApp}
              className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
            >
              Buka WhatsApp & Kirim Pesan
            </button>
          </div>
        </div>
      )}

      {/* EMAIL MODAL POPUP */}
      {showEmailModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold">
                <Mail className="w-5 h-5 text-amber-600" />
                <span>Kirim Notifikasi Email Resmi</span>
              </div>
              <button onClick={() => setShowEmailModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <label className="block font-bold text-slate-700">Alamat Email Tujuan:</label>
              <input
                type="email"
                value={targetEmail}
                onChange={(e) => setTargetEmail(e.target.value)}
                placeholder="pegawai@haji.go.id"
                className="w-full px-3 py-2 text-xs border rounded-xl"
              />
            </div>

            <button
              onClick={handleSendEmail}
              className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold text-xs"
            >
              Buka Email App & Kirim
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
