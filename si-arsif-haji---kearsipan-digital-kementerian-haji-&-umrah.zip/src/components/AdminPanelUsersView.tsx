import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { UserRole, UserProfile } from '../types/archive';
import {
  Users,
  UserPlus,
  Mail,
  Shield,
  Phone,
  Building,
  CheckCircle2,
  XCircle,
  Trash2,
  LogIn,
  Search,
  Key,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

export const AdminPanelUsersView: React.FC = () => {
  const { users, currentUser, registerUser, updateUser, deleteUser, switchUser } = useArchive();

  // New user form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [nip, setNip] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('PEGAWAI');
  const [unit, setUnit] = useState('Direktorat Pelayanan Haji');
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [searchUser, setSearchUser] = useState('');

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess(null);
    setFormError(null);

    if (!name.trim() || !email.trim()) {
      setFormError('Nama lengkap dan alamat email wajib diisi.');
      return;
    }

    const roleTitles: Record<UserRole, string> = {
      SUPER_ADMIN: 'Administrator Utama Kearsipan',
      ARSIPARIS: 'Arsiparis Ahli Kementerian Haji & Umrah',
      PEJABAT_VERIFIKATOR: 'Pejabat Verifikator & Disposisi',
      PEGAWAI: 'Pegawai Staf Kementerian Haji & Umrah',
      AUDITOR: 'Auditor Pengawasan Internal',
    };

    const res = registerUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      nip: nip.trim() || `199${Math.floor(1000000 + Math.random() * 8999999)}`,
      phone: phone.trim() || '0812' + Math.floor(10000000 + Math.random() * 89999999),
      role,
      roleTitle: roleTitles[role],
      unit: unit.trim() || 'Kementerian Haji dan Umrah RI',
      avatar: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 100000000)}?w=150&auto=format&fit=crop&q=80`,
      isActive: true,
    });

    if (res.success) {
      setFormSuccess(`Pengguna baru ${name} (${email}) berhasil didaftarkan ke sistem!`);
      setName('');
      setEmail('');
      setNip('');
      setPhone('');
    } else {
      setFormError(res.error || 'Gagal mendaftarkan pengguna.');
    }
  };

  const handleDeleteUser = (user: UserProfile) => {
    const confirmed = window.confirm(`Apakah Anda yakin ingin menghapus akun ${user.name} (${user.email})?`);
    if (confirmed) {
      const res = deleteUser(user.id);
      if (!res.success) {
        alert(res.error);
      }
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!searchUser.trim()) return true;
    const q = searchUser.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.nip.includes(q) ||
      u.role.toLowerCase().includes(q) ||
      u.unit.toLowerCase().includes(q)
    );
  });

  const getRoleBadge = (r: UserRole) => {
    switch (r) {
      case 'SUPER_ADMIN':
        return 'bg-amber-100 text-amber-900 border-amber-300 font-extrabold';
      case 'ARSIPARIS':
        return 'bg-slate-100 text-slate-900 border-slate-300 font-bold';
      case 'PEJABAT_VERIFIKATOR':
        return 'bg-stone-200 text-stone-900 border-stone-400 font-bold';
      case 'PEGAWAI':
        return 'bg-slate-50 text-slate-700 border-slate-200';
      case 'AUDITOR':
        return 'bg-red-50 text-red-900 border-red-200 font-bold';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner - Gold, Black & White Tone */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-zinc-900 to-stone-950 text-white p-6 sm:p-8 shadow-xl border border-amber-500/20 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-bold mb-3 border border-amber-500/30">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Panel Administrator Resmi • BUDIKA ARSIP</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Pendaftaran & Manajemen Akses Pengguna Berdasarkan Email
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Kelola data staf dan pejabat Kementerian Haji dan Umrah. Daftarkan akun baru dengan alamat email resmi,
            tentukan wewenang peran (*role*), dan atur hak akses terhadap arsip rahasia kementerian.
          </p>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Main Grid: Registration Form (Left) & Users List (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Registration Form Card */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200">
              <UserPlus className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-slate-900">Daftarkan Pengguna Baru</h3>
              <p className="text-xs text-slate-500">Masukkan data akun pegawai kantor haji</p>
            </div>
          </div>

          <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Nama Lengkap Pegawai <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Contoh: H. Ahmad Fauzi, S.Ag."
                required
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Alamat Email Resmi <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-3.5 h-3.5" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="pegawai@haji.go.id atau email google"
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                NIP / Nomor Identitas Pegawai
              </label>
              <input
                type="text"
                value={nip}
                onChange={(e) => setNip(e.target.value)}
                placeholder="Contoh: 19850614 201001 1 001"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Nomor Telepon / WhatsApp
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Contoh: 081288990011"
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Peran Pengguna (Role Akses) <span className="text-red-500">*</span>
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900 font-medium"
              >
                <option value="PEGAWAI">Pegawai Staf (Akses Arsip Terbuka & Dossier)</option>
                <option value="ARSIPARIS">Arsiparis Ahli (Pengelola Dokumen & JRA)</option>
                <option value="PEJABAT_VERIFIKATOR">Pejabat Verifikator (Persetujuan & Disposisi)</option>
                <option value="SUPER_ADMIN">Super Admin (Akses Penuh Seluruh Sistem)</option>
                <option value="AUDITOR">Auditor Pengawasan (Inspektorat Jenderal)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Unit Kerja / Direktorat
              </label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="Contoh: Direktorat Pelayanan Haji Luar Negeri"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
              />
            </div>

            {formSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{formSuccess}</span>
              </div>
            )}

            {formError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-900 text-xs flex items-center gap-2">
                <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <UserPlus className="w-4 h-4 text-amber-400" />
              Daftarkan Pengguna Ini
            </button>
          </form>
        </div>

        {/* Users List (Right 2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Daftar Pengguna Terdaftar ({users.length} Akun)
                </h3>
                <p className="text-xs text-slate-500">
                  Data pengguna resmi sistem kearsipan Kementerian Haji dan Umrah
                </p>
              </div>

              <div className="relative max-w-xs w-full">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Search className="w-3.5 h-3.5" />
                </div>
                <input
                  type="text"
                  value={searchUser}
                  onChange={(e) => setSearchUser(e.target.value)}
                  placeholder="Cari nama, email, NIP, unit..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
                />
              </div>
            </div>

            {/* User Cards List */}
            <div className="space-y-3 pt-2">
              {filteredUsers.map((user) => {
                const isCurrent = currentUser.id === user.id;

                return (
                  <div
                    key={user.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isCurrent
                        ? 'bg-amber-50/40 border-amber-300 ring-2 ring-amber-400/20'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-11 h-11 rounded-xl object-cover ring-1 ring-slate-200 shrink-0"
                        />
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="text-xs font-bold text-slate-900">{user.name}</h4>
                            <span
                              className={`text-[10px] px-2 py-0.2 rounded-full border ${getRoleBadge(
                                user.role
                              )}`}
                            >
                              {user.role}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-extrabold px-2 py-0.2 rounded-full bg-slate-900 text-amber-300">
                                SEDANG DIGUNAKAN
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500 mt-1">
                            <span className="flex items-center gap-1 font-mono text-slate-700">
                              <Mail className="w-3 h-3 text-amber-600" />
                              {user.email}
                            </span>
                            <span className="font-mono text-slate-400">NIP: {user.nip}</span>
                            <span className="text-slate-600">{user.unit}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        {!isCurrent && (
                          <button
                            onClick={() => switchUser(user.id)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-black text-amber-300 shadow-xs transition-all active:scale-95"
                            title="Masuk sebagai akun pengguna ini"
                          >
                            <LogIn className="w-3.5 h-3.5" />
                            <span>Gunakan Akun</span>
                          </button>
                        )}

                        {!isCurrent && (
                          <button
                            onClick={() => handleDeleteUser(user)}
                            className="p-1.5 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            title="Hapus Pengguna"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
