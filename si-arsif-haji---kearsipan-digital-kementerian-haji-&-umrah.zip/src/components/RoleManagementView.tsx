import React from 'react';
import { useArchive } from '../context/ArchiveContext';
import { UserRole } from '../types/archive';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Users,
} from 'lucide-react';

export const RoleManagementView: React.FC = () => {
  const { currentUser, switchUser, users, setActiveTab } = useArchive();

  // Matrix of permissions for each role
  const permissions = [
    {
      feature: 'Melihat Arsip Publik & Terbatas',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: true,
      auditor: true,
    },
    {
      feature: 'Mengunggah Berkas Baru & Deteksi AI',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: true,
      auditor: false,
    },
    {
      feature: 'Akses Berkas Kepegawaian Pribadi (Dossier)',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: true,
      auditor: true,
    },
    {
      feature: 'Enkripsi & Dekripsi Dokumen Rahasia AES-256',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: false,
      auditor: true,
    },
    {
      feature: 'Verifikasi & Disposisi Status Kearsipan',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: false,
      auditor: false,
    },
    {
      feature: 'Sinkronisasi Cloud Google Drive',
      superAdmin: true,
      arsiparis: true,
      pejabat: false,
      pegawai: false,
      auditor: false,
    },
    {
      feature: 'Inspeksi Jejak Audit Trail & Hash Integritas',
      superAdmin: true,
      arsiparis: true,
      pejabat: true,
      pegawai: false,
      auditor: true,
    },
    {
      feature: 'Pencadangan & Pemulihan Sistem (Backup/Restore)',
      superAdmin: true,
      arsiparis: false,
      pejabat: false,
      pegawai: false,
      auditor: false,
    },
    {
      feature: 'Penghapusan Arsip Definitif (Single & Massal)',
      superAdmin: true,
      arsiparis: false,
      pejabat: false,
      pegawai: false,
      auditor: false,
    },
    {
      feature: 'Pendaftaran Akun Pegawai Berdasarkan Email',
      superAdmin: true,
      arsiparis: false,
      pejabat: false,
      pegawai: false,
      auditor: false,
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200">
            <ShieldCheck className="w-6 h-6 text-amber-700" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              Sistem Manajemen Akses Berbasis Peran (RBAC)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Pengaturan hierarki wewenang kearsipan & standar keamanan informasi Kementerian Haji dan Umrah RI
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('admin_users')}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-950 hover:bg-black text-amber-400 font-bold text-xs shadow-sm transition-all"
        >
          <Users className="w-4 h-4 text-amber-400" />
          <span>Buka Panel Admin Pengguna</span>
        </button>
      </div>

      {/* User Profiles / Role Simulator Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Profil Pengguna Terdaftar ({users.length} Akun • Klik untuk beralih akun simulasi)
          </h3>
          <span className="text-xs text-slate-400">
            RBAC Aktif
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {users.map((user) => {
            const isCurrent = currentUser.id === user.id;
            return (
              <div
                key={user.id}
                onClick={() => switchUser(user.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer text-left ${
                  isCurrent
                    ? 'bg-amber-50/60 border-amber-400 ring-2 ring-amber-400/20 shadow-sm'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-center gap-3">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-200 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 font-mono">
                        NIP: {user.nip}
                      </span>
                      {isCurrent && (
                        <span className="text-[10px] font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-full">
                          AKTIF
                        </span>
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 truncate mt-0.5">
                      {user.name}
                    </h4>
                    <p className="text-[11px] font-medium text-amber-800 truncate">
                      {user.roleTitle}
                    </p>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                  <span className="truncate">{user.unit}</span>
                  <span className="font-bold text-xs text-slate-900 font-mono">
                    [{user.role}]
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* RBAC Matrix Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Matriks Hak Akses Kearsipan (Access Control Matrix)
          </h3>
          <span className="text-xs text-slate-500">Standar Pengamanan Informasi Kementerian Haji dan Umrah</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase">
                <th className="py-3 px-4">Fitur / Operasi Kearsipan</th>
                <th className="py-3 px-3 text-center">Super Admin</th>
                <th className="py-3 px-3 text-center">Arsiparis</th>
                <th className="py-3 px-3 text-center">Pejabat Verifikator</th>
                <th className="py-3 px-3 text-center">Pegawai Staf</th>
                <th className="py-3 px-3 text-center">Auditor Internal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {permissions.map((perm, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-medium text-slate-900">{perm.feature}</td>
                  <td className="py-3 px-3 text-center">
                    {perm.superAdmin ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-500 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {perm.arsiparis ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-500 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {perm.pejabat ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-500 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {perm.pegawai ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-500 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {perm.auditor ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-500 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
