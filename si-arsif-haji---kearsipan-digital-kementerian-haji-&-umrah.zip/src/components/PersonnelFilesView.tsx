import React, { useState, useMemo } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { PersonnelType } from '../types/archive';
import {
  UserCheck,
  Search,
  PlusCircle,
  Award,
  Plane,
  Briefcase,
  Lock,
  Eye,
  CloudCheck,
  Calendar,
  Building2,
  Trash2,
  FileText,
} from 'lucide-react';

export const PersonnelFilesView: React.FC = () => {
  const {
    documents,
    currentUser,
    setSelectedDocumentForDetail,
    deleteDocument,
    setIsUploadModalOpen,
    setUploadInitialPersonnelOnly,
  } = useArchive();

  const [personnelSearch, setPersonnelSearch] = useState<string>('');
  const [selectedSubtype, setSelectedSubtype] = useState<string>('ALL');

  // Filter documents that are personnel files
  const personnelDocs = useMemo(() => {
    return documents.filter((doc) => {
      if (!doc.isPersonnelFile) return false;

      if (selectedSubtype !== 'ALL' && doc.personnelType !== selectedSubtype) {
        return false;
      }

      if (personnelSearch.trim()) {
        const q = personnelSearch.toLowerCase();
        const matchTitle = doc.title.toLowerCase().includes(q);
        const matchDocNum = doc.docNumber.toLowerCase().includes(q);
        const matchSummary = doc.summary.toLowerCase().includes(q);
        const matchOwner = (doc.personnelOwnerName || doc.ownerName).toLowerCase().includes(q);
        const matchNip = (doc.personnelOwnerNip || doc.ownerNip).includes(q);

        if (!matchTitle && !matchDocNum && !matchSummary && !matchOwner && !matchNip) {
          return false;
        }
      }

      return true;
    });
  }, [documents, selectedSubtype, personnelSearch]);

  const handleUploadPersonnel = () => {
    setUploadInitialPersonnelOnly(true);
    setIsUploadModalOpen(true);
  };

  const handleDeletePersonnel = async (e: React.MouseEvent, docId: string, title: string) => {
    e.stopPropagation();
    const confirmed = window.confirm(`Hapus berkas kepegawaian "${title}"?`);
    if (confirmed) {
      await deleteDocument(docId);
    }
  };

  const getTypeIcon = (type?: PersonnelType) => {
    switch (type) {
      case 'SK_KENAIKAN_PANGKAT':
      case 'SK_PNS':
        return Briefcase;
      case 'SERTIFIKAT_PPIH':
        return Award;
      case 'PASPOR_DINAS':
      case 'SURAT_TUGAS_ARAB_SAUDI':
        return Plane;
      default:
        return FileText;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Employee Dossier Header Card - Gold & Black theme */}
      <div className="bg-gradient-to-r from-slate-950 via-zinc-900 to-stone-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-500/20 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-2 ring-amber-400/50 shadow-md shrink-0"
            />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 tracking-wider uppercase">
                  Dossier Pegawai
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/10 text-slate-200 border border-white/20">
                  {currentUser.roleTitle}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
                {currentUser.name}
              </h2>
              <p className="text-xs sm:text-sm font-mono text-amber-300">
                NIP: {currentUser.nip} • {currentUser.email}
              </p>
              <p className="text-xs text-slate-300 mt-1 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-amber-400" />
                {currentUser.unit}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={handleUploadPersonnel}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm shadow-md active:scale-95 transition-all"
            >
              <PlusCircle className="w-4 h-4 text-slate-950" />
              Unggah Berkas Saya
            </button>
          </div>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Filter and Search Bar for Personnel Files */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={personnelSearch}
              onChange={(e) => setPersonnelSearch(e.target.value)}
              placeholder="Cari dalam berkas kepegawaian (SK Pangkat, Paspor Dinas, Sertifikat PPIH, SKP...)"
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
            />
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Total: <strong className="text-slate-950 font-bold">{personnelDocs.length}</strong> berkas kepegawaian
          </div>
        </div>

        {/* Subtype Category Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
          {[
            { id: 'ALL', label: 'Semua Berkas' },
            { id: 'SK_KENAIKAN_PANGKAT', label: 'SK Kenaikan Pangkat' },
            { id: 'SERTIFIKAT_PPIH', label: 'Sertifikat Bimtek PPIH' },
            { id: 'PASPOR_DINAS', label: 'Paspor Dinas & Visa Haji' },
            { id: 'SKP_KINERJA', label: 'SKP & Kinerja' },
            { id: 'SK_PNS', label: 'SK Pengangkatan' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedSubtype(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedSubtype === tab.id
                  ? 'bg-slate-950 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Personnel Dossier Files */}
      {personnelDocs.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center">
          <UserCheck className="w-10 h-10 text-slate-400 mx-auto mb-2" />
          <h4 className="text-sm font-bold text-slate-900">Belum ada berkas kepegawaian pada filter ini</h4>
          <p className="text-xs text-slate-500 mt-1">
            Klik tombol "Unggah Berkas Saya" untuk menyimpan SK atau sertifikat Anda secara aman.
          </p>
          <button
            onClick={handleUploadPersonnel}
            className="mt-4 px-4 py-2 text-xs font-bold rounded-xl bg-slate-950 text-amber-400 hover:bg-black"
          >
            Unggah Berkas Kepegawaian Sekarang
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {personnelDocs.map((doc) => {
            const Icon = getTypeIcon(doc.personnelType);
            return (
              <div
                key={doc.id}
                onClick={() => setSelectedDocumentForDetail(doc)}
                className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md cursor-pointer transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200 group-hover:bg-amber-100 transition-colors">
                      <Icon className="w-5 h-5 text-amber-700" />
                    </div>
                    <div className="flex items-center gap-1.5">
                      {doc.isEncrypted && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-900 bg-amber-100 px-2 py-0.5 rounded-md border border-amber-300">
                          <Lock className="w-3 h-3 text-amber-700" /> AES-256
                        </span>
                      )}
                      {doc.gdriveSynced && (
                        <span className="p-1 rounded-md text-amber-800 bg-amber-50 border border-amber-200" title="Tersimpan di Google Drive">
                          <CloudCheck className="w-3.5 h-3.5 text-amber-600" />
                        </span>
                      )}
                    </div>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900 group-hover:text-amber-950 mt-3 line-clamp-2 leading-snug">
                    {doc.title}
                  </h3>

                  <p className="font-mono text-[11px] text-slate-500 mt-1">
                    {doc.docNumber}
                  </p>

                  <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                    {doc.summary}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1 text-[11px]">
                    <Calendar className="w-3.5 h-3.5" />
                    {doc.year}
                  </span>
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => setSelectedDocumentForDetail(doc)}
                      className="font-bold text-slate-900 flex items-center gap-1 text-xs hover:text-amber-600 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-lg"
                    >
                      <Eye className="w-3.5 h-3.5 text-amber-500" /> Pratinjau
                    </button>
                    <button
                      onClick={(e) => handleDeletePersonnel(e, doc.id, doc.title)}
                      className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                      title="Hapus Berkas Ini"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
