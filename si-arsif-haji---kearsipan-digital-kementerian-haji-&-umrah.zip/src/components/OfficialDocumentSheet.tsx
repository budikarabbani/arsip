import React from 'react';
import { ArchiveDocument } from '../types/archive';
import { ShieldCheck, Lock, Unlock, CheckCircle2, QrCode } from 'lucide-react';

interface OfficialDocumentSheetProps {
  doc: ArchiveDocument;
  decryptedText: string | null;
  onDecryptClick?: () => void;
  isDecrypting?: boolean;
  zoomLevel?: number;
}

export const OfficialDocumentSheet: React.FC<OfficialDocumentSheetProps> = ({
  doc,
  decryptedText,
  onDecryptClick,
  isDecrypting = false,
  zoomLevel = 100,
}) => {
  const formattedDate = new Date(doc.uploadDate).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const contentText = decryptedText || doc.fileData || doc.summary;
  const isImageFile = doc.fileData?.startsWith('data:image/');
  const isPdfData = doc.fileData?.startsWith('data:application/pdf');

  return (
    <div
      className="bg-white text-slate-900 shadow-xl border border-slate-300 mx-auto transition-transform duration-150 origin-top p-6 sm:p-10 md:p-12 font-serif text-xs leading-relaxed max-w-3xl"
      style={{
        transform: `scale(${zoomLevel / 100})`,
        minHeight: '850px',
      }}
      id="printable-official-document"
    >
      {/* Official Kop Surat Kementerian Haji dan Umrah Republik Indonesia */}
      <div className="border-b-2 border-slate-900 pb-3 mb-1 text-center relative">
        {/* Lambang Garuda Pancasila Emas */}
        <div className="flex justify-center mb-2">
          <div className="w-16 h-16 flex items-center justify-center text-amber-500">
            <svg
              viewBox="0 0 100 100"
              className="w-14 h-14 fill-current drop-shadow-xs"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Garuda Pancasila SVG Stylized Emblem */}
              <path d="M50 5 L61 22 L82 22 L67 36 L73 57 L50 45 L27 57 L33 36 L18 22 L39 22 Z" fill="#D4AF37" stroke="#996515" strokeWidth="1" />
              <circle cx="50" cy="40" r="16" fill="#000000" />
              <path d="M50 28 L54 36 L62 36 L56 42 L58 50 L50 45 L42 50 L44 42 L38 36 L46 36 Z" fill="#FFD700" />
              <rect x="42" y="58" width="16" height="4" rx="2" fill="#D4AF37" />
              <text x="50" y="70" fontSize="7" textAnchor="middle" fontWeight="bold" fill="#020617" fontFamily="sans-serif">
                BHINNEKA TUNGGAL IKA
              </text>
            </svg>
          </div>
        </div>

        <h1 className="text-base sm:text-lg font-black tracking-wider uppercase text-slate-950 font-sans">
          KEMENTERIAN HAJI DAN UMRAH
        </h1>
        <h2 className="text-sm sm:text-base font-extrabold tracking-widest uppercase text-slate-900 font-sans">
          REPUBLIK INDONESIA
        </h2>
        <p className="text-[10px] text-slate-600 font-sans mt-0.5">
          Jalan Lapangan Banteng Barat No. 3-4, Jakarta Pusat 10710 • Telepon: (021) 3811642, 3811654
        </p>
        <p className="text-[10px] text-slate-500 font-sans">
          Laman Resmi: <span className="text-slate-800 underline">https://haji.go.id</span> • Pos-el: <span className="text-slate-800">persuratan@haji.go.id</span>
        </p>
      </div>
      {/* Garis Ganda Tipis Kop Surat */}
      <div className="border-b border-slate-900 mb-6" />

      {/* Header Info Surat (Nomor, Sifat, Hal, Tanggal) */}
      <div className="flex flex-col sm:flex-row justify-between gap-4 mb-6 text-xs font-sans">
        <div className="space-y-1">
          <div className="flex gap-2">
            <span className="w-20 font-bold text-slate-700">Nomor</span>
            <span>: <strong className="font-mono text-slate-900">{doc.docNumber}</strong></span>
          </div>
          <div className="flex gap-2">
            <span className="w-20 font-bold text-slate-700">Sifat</span>
            <span>: <span className="font-bold uppercase text-slate-900">{doc.securityLevel}</span></span>
          </div>
          <div className="flex gap-2">
            <span className="w-20 font-bold text-slate-700">Lampiran</span>
            <span>: 1 (satu) Berkas Digital</span>
          </div>
          <div className="flex gap-2">
            <span className="w-20 font-bold text-slate-700">Hal</span>
            <span>: <strong className="text-slate-950">{doc.title}</strong></span>
          </div>
        </div>

        <div className="text-right sm:min-w-[180px]">
          <p className="text-slate-800 font-medium">Jakarta, {formattedDate}</p>
          <div className="mt-3 text-left sm:text-right">
            <p className="text-slate-600">Kepada Yth:</p>
            <p className="font-bold text-slate-900">
              {doc.ownerUnit || 'Seluruh Pejabat & Pegawai Terkait'}
            </p>
            <p className="text-slate-600">Kementerian Haji dan Umrah RI</p>
            <p className="text-slate-600">di Tempat</p>
          </div>
        </div>
      </div>

      {/* Pembuka Naskah Dinas */}
      <div className="mb-4 text-justify leading-relaxed">
        <p>
          Sehubungan dengan pelaksanaan tugas pemerintahan di bidang pengelolaan kearsipan dan penyelenggaraan ibadah haji nasional, bersama ini disampaikan naskah dinas resmi kementerian dengan ketentuan sebagai berikut:
        </p>
      </div>

      {/* Batang Tubuh Dokumen (Isi Naskah) */}
      <div className="my-5 p-5 bg-slate-50/70 rounded-2xl border border-slate-200">
        {doc.isEncrypted && !decryptedText ? (
          <div className="py-6 px-4 text-center space-y-3 bg-amber-50/50 rounded-xl border border-amber-300">
            <div className="w-12 h-12 rounded-full bg-slate-950 text-amber-400 mx-auto flex items-center justify-center shadow-md">
              <Lock className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-black text-slate-950 font-sans">
              DOKUMEN RAHASIA TERENKRIPSI (AES-GCM 256-BIT)
            </h4>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed font-sans">
              Dokumen ini berstatus <strong>{doc.securityLevel}</strong> dan dilindungi enkripsi kriptografis tingkat tinggi. Kunci otorisasi kementerian diperlukan untuk membaca lembar naskah dinas ini.
            </p>
            {onDecryptClick && (
              <button
                onClick={onDecryptClick}
                disabled={isDecrypting}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-md transition-all active:scale-95 font-sans"
              >
                <Unlock className="w-4 h-4 text-amber-400" />
                <span>{isDecrypting ? 'Mendekripsi...' : 'Buka Kunci Enkripsi Naskah'}</span>
              </button>
            )}
          </div>
        ) : isImageFile ? (
          <div className="text-center space-y-3">
            <img
              src={doc.fileData}
              alt={doc.title}
              className="max-h-96 mx-auto rounded-xl border border-slate-300 shadow-sm object-contain"
            />
            <p className="text-[11px] text-slate-500 font-sans italic">
              Lampiran visual berkas: {doc.fileName}
            </p>
          </div>
        ) : isPdfData ? (
          <div className="space-y-3">
            <iframe
              src={doc.fileData}
              title={doc.title}
              className="w-full h-96 rounded-xl border border-slate-300 shadow-sm"
            />
          </div>
        ) : (
          <div className="space-y-4 text-justify font-serif text-slate-800 leading-relaxed whitespace-pre-wrap">
            <p className="font-bold text-center text-xs tracking-wider font-sans mb-3 text-slate-950 uppercase">
              KETETAPAN & ISI DOKUMEN KEARSIPAN
            </p>
            <div className="text-xs space-y-2">
              {contentText.split('\n').map((paragraph, idx) => (
                <p key={idx} className="indent-6">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Penutup */}
      <div className="mb-8 text-justify leading-relaxed">
        <p>
          Demikian naskah dinas ini ditetapkan dan diarsipkan secara elektronik dalam sistem informasi kearsipan resmi <strong>BUDIKA ARSIP</strong> Kementerian Haji dan Umrah Republik Indonesia, untuk diketahui dan dipedomani oleh seluruh pihak yang berkepentingan.
        </p>
      </div>

      {/* Bagian Tanda Tangan Elektronik Resmi (TTE) & QR Code Barcode */}
      <div className="flex flex-col sm:flex-row justify-between items-end gap-6 pt-6 border-t border-slate-200 font-sans text-xs">
        {/* Barcode & Security Stamp */}
        <div className="space-y-2 max-w-xs">
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
            {/* Real SVG QR Code representation */}
            <div className="p-1.5 bg-white rounded-lg border border-slate-300 shrink-0">
              <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="3" y="3" width="7" height="7" fill="#020617" stroke="none" />
                <rect x="14" y="3" width="7" height="7" fill="#020617" stroke="none" />
                <rect x="3" y="14" width="7" height="7" fill="#020617" stroke="none" />
                <rect x="5" y="5" width="3" height="3" fill="#ffffff" stroke="none" />
                <rect x="16" y="5" width="3" height="3" fill="#ffffff" stroke="none" />
                <rect x="5" y="16" width="3" height="3" fill="#ffffff" stroke="none" />
                <rect x="14" y="14" width="3" height="3" fill="#020617" stroke="none" />
                <rect x="18" y="18" width="3" height="3" fill="#020617" stroke="none" />
                <rect x="14" y="18" width="3" height="3" fill="#020617" stroke="none" />
                <rect x="18" y="14" width="3" height="3" fill="#020617" stroke="none" />
              </svg>
            </div>
            <div className="text-[10px] text-slate-600 leading-tight">
              <span className="font-bold text-slate-900 block flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-amber-600" /> TTE Tersertifikasi BSrE
              </span>
              <span>Pindai barcode untuk verifikasi keabsahan dokumen kearsipan</span>
            </div>
          </div>
          <p className="text-[9px] font-mono text-slate-400 break-all">
            SHA-256: {doc.sha256Hash}
          </p>
        </div>

        {/* Pejabat Penandatangan */}
        <div className="text-right sm:min-w-[220px]">
          <p className="text-slate-800 font-medium">
            Kementerian Haji dan Umrah RI
          </p>
          <p className="font-bold text-slate-950 mt-0.5">
            {doc.lastVerifiedBy ? 'Pejabat Verifikator Kearsipan,' : 'Pengunggah Berkas,'}
          </p>

          {/* Digital Signature Badge */}
          <div className="my-2 inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-950 rounded-lg border border-amber-300 text-[10px] font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
            <span>Ditandatangani secara elektronik</span>
          </div>

          <p className="font-black text-slate-950 underline mt-2 text-xs">
            {doc.lastVerifiedBy || doc.ownerName}
          </p>
          <p className="text-[10px] text-slate-500 font-mono">
            NIP. {doc.ownerNip}
          </p>
        </div>
      </div>

      {/* Tembusan */}
      <div className="mt-8 pt-4 border-t border-slate-100 text-[10px] font-sans text-slate-500 space-y-0.5">
        <p className="font-bold text-slate-700">Tembusan Yth:</p>
        <p>1. Menteri Haji dan Umrah Republik Indonesia</p>
        <p>2. Sekretaris Jenderal Kementerian Haji dan Umrah RI</p>
        <p>3. Inspektur Jenderal Kementerian Haji dan Umrah RI</p>
        <p>4. Arsiparis Pusat / Biro Umum Kementerian Haji dan Umrah RI</p>
      </div>
    </div>
  );
};
