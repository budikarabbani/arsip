import React, { useState, useMemo } from 'react';
import { useArchive } from '../context/ArchiveContext';
import { ArchiveCategory, SecurityLevel, DocumentStatus, ArchiveDocument } from '../types/archive';
import {
  Search,
  Filter,
  Lock,
  CloudCheck,
  CloudOff,
  Eye,
  Trash2,
  Sparkles,
  RefreshCw,
  FileText,
  CheckSquare,
  Square,
  AlertTriangle,
} from 'lucide-react';

export const ArchiveListView: React.FC = () => {
  const {
    documents,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    setSelectedDocumentForDetail,
    deleteDocument,
    bulkDeleteDocuments,
    syncDocumentToDrive,
    setIsUploadModalOpen,
  } = useArchive();

  const [selectedSecurity, setSelectedSecurity] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [onlyEncrypted, setOnlyEncrypted] = useState<boolean>(false);
  const [onlyGDrive, setOnlyGDrive] = useState<boolean>(false);
  const [syncingDocId, setSyncingDocId] = useState<string | null>(null);

  // Multi-select for bulk delete
  const [selectedDocIds, setSelectedDocIds] = useState<string[]>([]);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Filtered documents list
  const filteredDocuments = useMemo(() => {
    return documents.filter((doc) => {
      // Global Search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = doc.title.toLowerCase().includes(query);
        const matchesDocNumber = doc.docNumber.toLowerCase().includes(query);
        const matchesOwner = doc.ownerName.toLowerCase().includes(query);
        const matchesNip = doc.ownerNip.includes(query);
        const matchesKeywords = doc.keywords.some((k) => k.toLowerCase().includes(query));
        const matchesSummary = doc.summary.toLowerCase().includes(query);

        if (!matchesTitle && !matchesDocNumber && !matchesOwner && !matchesNip && !matchesKeywords && !matchesSummary) {
          return false;
        }
      }

      // Category filter
      if (selectedCategory !== 'ALL' && doc.category !== selectedCategory) {
        return false;
      }

      // Security level filter
      if (selectedSecurity !== 'ALL' && doc.securityLevel !== selectedSecurity) {
        return false;
      }

      // Status filter
      if (selectedStatus !== 'ALL' && doc.status !== selectedStatus) {
        return false;
      }

      // Only encrypted filter
      if (onlyEncrypted && !doc.isEncrypted) {
        return false;
      }

      // Only Google Drive filter
      if (onlyGDrive && !doc.gdriveSynced) {
        return false;
      }

      return true;
    });
  }, [documents, searchQuery, selectedCategory, selectedSecurity, selectedStatus, onlyEncrypted, onlyGDrive]);

  const handleSyncDoc = async (e: React.MouseEvent, docId: string) => {
    e.stopPropagation();
    setSyncingDocId(docId);
    await syncDocumentToDrive(docId);
    setSyncingDocId(null);
  };

  // Single delete
  const handleDelete = async (e: React.MouseEvent, doc: ArchiveDocument) => {
    e.stopPropagation();
    const confirmed = window.confirm(
      `HAPUS BERKAS?\n\nJudul: "${doc.title}"\nNomor: ${doc.docNumber}\n\nApakah Anda yakin ingin menghapus berkas ini secara permanen dari sistem?`
    );
    if (confirmed) {
      setIsDeleting(true);
      await deleteDocument(doc.id);
      setSelectedDocIds((prev) => prev.filter((id) => id !== doc.id));
      setIsDeleting(false);
    }
  };

  // Multi select toggle
  const toggleSelectDoc = (docId: string) => {
    setSelectedDocIds((prev) =>
      prev.includes(docId) ? prev.filter((id) => id !== docId) : [...prev, docId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedDocIds.length === filteredDocuments.length) {
      setSelectedDocIds([]);
    } else {
      setSelectedDocIds(filteredDocuments.map((d) => d.id));
    }
  };

  // Bulk delete
  const handleBulkDelete = async () => {
    if (selectedDocIds.length === 0) return;
    const confirmed = window.confirm(
      `HAPUS MASSAL?\n\nAnda akan menghapus ${selectedDocIds.length} berkas yang dipilih secara permanen.\n\nLanjutkan penghapusan?`
    );
    if (confirmed) {
      setIsDeleting(true);
      await bulkDeleteDocuments(selectedDocIds);
      setSelectedDocIds([]);
      setIsDeleting(false);
    }
  };

  const getSecurityBadge = (level: SecurityLevel) => {
    switch (level) {
      case 'Publik':
        return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'Terbatas':
        return 'bg-zinc-100 text-zinc-900 border-zinc-300 font-semibold';
      case 'Rahasia':
        return 'bg-amber-100 text-amber-950 border-amber-300 font-bold';
      case 'Sangat Rahasia':
        return 'bg-red-100 text-red-950 border-red-300 font-extrabold';
    }
  };

  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'Diarsipkan':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold';
      case 'Diverifikasi':
        return 'bg-amber-100 text-amber-900 border-amber-300 font-semibold';
      case 'Menunggu Verifikasi':
        return 'bg-stone-100 text-stone-800 border-stone-300';
      case 'Draf':
        return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'Ditolak':
        return 'bg-red-100 text-red-900 border-red-200';
    }
  };

  const allCategories: ArchiveCategory[] = [
    'Regulasi & Kebijakan Haji',
    'Kepegawaian & Petugas Haji',
    'Operasional Kuota & Paspor Jemaah',
    'Layanan Akomodasi & Masyair',
    'Keuangan & BPIH',
    'Kerjasama Bilateral & Syarikah',
    'Surat Dinas & Disposisi',
    'Umum & Publikasi',
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Controls & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-slate-950 tracking-tight">Bank Arsip Digital</h2>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-900 text-amber-400">
              {filteredDocuments.length} Dokumen
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Kementerian Haji dan Umrah Republik Indonesia • Tata Kelola Kearsipan Resmi
          </p>
        </div>

        <div className="flex items-center gap-2">
          {selectedDocIds.length > 0 && (
            <button
              onClick={handleBulkDelete}
              disabled={isDeleting}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-xs transition-all active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus ({selectedDocIds.length}) Berkas</span>
            </button>
          )}

          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-sm transition-all"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            Unggah Berkas Baru
          </button>
        </div>
      </div>

      {/* Filter Toolbar - Clean, Non-Ribet */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari berdasarkan kata kunci, judul, nomor SK/surat, nama pegawai, NIP..."
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-700"
            >
              <option value="ALL">Semua Kategori</option>
              {allCategories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            {/* Security Level Filter */}
            <select
              value={selectedSecurity}
              onChange={(e) => setSelectedSecurity(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-700"
            >
              <option value="ALL">Semua Keamanan</option>
              <option value="Publik">Publik</option>
              <option value="Terbatas">Terbatas</option>
              <option value="Rahasia">Rahasia</option>
              <option value="Sangat Rahasia">Sangat Rahasia</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-700"
            >
              <option value="ALL">Semua Status</option>
              <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
              <option value="Diverifikasi">Diverifikasi</option>
              <option value="Diarsipkan">Diarsipkan</option>
              <option value="Draf">Draf</option>
              <option value="Ditolak">Ditolak</option>
            </select>

            {/* Encryption toggle pill */}
            <button
              onClick={() => setOnlyEncrypted(!onlyEncrypted)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                onlyEncrypted
                  ? 'bg-amber-100 text-amber-950 border-amber-400'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Terenkripsi</span>
            </button>

            {/* GDrive toggle pill */}
            <button
              onClick={() => setOnlyGDrive(!onlyGDrive)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                onlyGDrive
                  ? 'bg-slate-900 text-amber-300 border-slate-800'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <CloudCheck className="w-3.5 h-3.5" />
              <span>Google Drive</span>
            </button>
          </div>
        </div>
      </div>

      {/* Documents List Table */}
      {filteredDocuments.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Tidak ada dokumen yang cocok</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            Ubah kata kunci pencarian atau sesuaikan filter di atas.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('ALL');
              setSelectedSecurity('ALL');
              setSelectedStatus('ALL');
              setOnlyEncrypted(false);
              setOnlyGDrive(false);
            }}
            className="mt-4 px-4 py-2 text-xs font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700"
          >
            Reset Semua Filter
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-3 text-center w-10">
                    <button
                      onClick={toggleSelectAll}
                      className="text-slate-500 hover:text-slate-900"
                      title="Pilih Semua"
                    >
                      {selectedDocIds.length === filteredDocuments.length ? (
                        <CheckSquare className="w-4 h-4 text-amber-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3.5 px-3">Dokumen & No. Berkas</th>
                  <th className="py-3.5 px-3">Kategori</th>
                  <th className="py-3.5 px-3">Keamanan</th>
                  <th className="py-3.5 px-3">Enkripsi</th>
                  <th className="py-3.5 px-3">Status</th>
                  <th className="py-3.5 px-3">Google Drive</th>
                  <th className="py-3.5 px-3">Tanggal</th>
                  <th className="py-3.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredDocuments.map((doc) => {
                  const isChecked = selectedDocIds.includes(doc.id);

                  return (
                    <tr
                      key={doc.id}
                      onClick={() => setSelectedDocumentForDetail(doc)}
                      className={`hover:bg-amber-50/20 transition-colors cursor-pointer group ${
                        isChecked ? 'bg-amber-50/40' : ''
                      }`}
                    >
                      {/* Checkbox column */}
                      <td
                        className="py-3.5 px-3 text-center"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSelectDoc(doc.id);
                        }}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-amber-600" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
                        )}
                      </td>

                      {/* Document Title & Number */}
                      <td className="py-3.5 px-3 max-w-xs sm:max-w-md">
                        <div className="flex items-start gap-2.5">
                          <div className="p-2 rounded-xl bg-slate-100 text-slate-600 group-hover:bg-amber-100 group-hover:text-amber-900 transition-colors shrink-0 mt-0.5">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-slate-900 group-hover:text-amber-950 truncate leading-snug">
                              {doc.title}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 mt-1">
                              <span className="font-mono text-[11px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded">
                                {doc.docNumber}
                              </span>
                              {doc.isPersonnelFile && (
                                <span className="text-[10px] bg-stone-100 text-stone-800 px-1.5 py-0.2 rounded font-bold border border-stone-300">
                                  Berkas Pegawai
                                </span>
                              )}
                              {doc.aiClassified && (
                                <span className="inline-flex items-center gap-0.5 text-[10px] text-amber-900 font-bold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                                  <Sparkles className="w-2.5 h-2.5 text-amber-600" /> AI
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="font-medium text-slate-800">{doc.category}</span>
                        <p className="text-[11px] text-slate-400 truncate max-w-[140px]">
                          {doc.subCategory}
                        </p>
                      </td>

                      {/* Security Level */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${getSecurityBadge(
                            doc.securityLevel
                          )}`}
                        >
                          {doc.securityLevel}
                        </span>
                      </td>

                      {/* Encryption status */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        {doc.isEncrypted ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md">
                            <Lock className="w-3 h-3 text-amber-700" /> AES-256
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">Standar</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded-full border ${getStatusBadge(
                            doc.status
                          )}`}
                        >
                          {doc.status}
                        </span>
                      </td>

                      {/* Google Drive Status */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        {doc.gdriveSynced ? (
                          <div className="flex items-center gap-1.5 text-amber-800 text-xs font-bold">
                            <CloudCheck className="w-4 h-4 text-amber-600" />
                            <span>Tersinkron</span>
                          </div>
                        ) : (
                          <button
                            onClick={(e) => handleSyncDoc(e, doc.id)}
                            disabled={syncingDocId === doc.id}
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 px-2 py-1 rounded-lg border border-slate-200 transition-colors"
                            title="Sinkronkan ke Google Drive"
                          >
                            {syncingDocId === doc.id ? (
                              <RefreshCw className="w-3 h-3 animate-spin text-amber-600" />
                            ) : (
                              <CloudOff className="w-3 h-3" />
                            )}
                            <span>Sync Drive</span>
                          </button>
                        )}
                      </td>

                      {/* Upload Date */}
                      <td className="py-3.5 px-3 whitespace-nowrap text-slate-500 text-[11px]">
                        {new Date(doc.uploadDate).toLocaleDateString('id-ID', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </td>

                      {/* Action buttons (Lihat & Hapus Berkas) */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => setSelectedDocumentForDetail(doc)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-950 text-amber-300 hover:bg-black transition-all shadow-xs"
                            title="Pratinjau & Buka Naskah Dokumen"
                          >
                            <Eye className="w-3.5 h-3.5 text-amber-400" />
                            <span>Pratinjau</span>
                          </button>

                          {/* Explicit Delete Button */}
                          <button
                            onClick={(e) => handleDelete(e, doc)}
                            className="p-1.5 rounded-lg text-red-500 hover:text-red-700 hover:bg-red-50 transition-colors"
                            title="Hapus Dokumen Ini"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
