import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import {
  Lock,
  Unlock,
  ShieldCheck,
  Key,
  FileText,
  Eye,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
} from 'lucide-react';
import { ArchiveDocument } from '../types/archive';

export const EncryptedVaultView: React.FC = () => {
  const { documents, decryptDoc, setSelectedDocumentForDetail } = useArchive();

  const [masterPassphrase, setMasterPassphrase] = useState<string>('BUDIKA-HAJI-SECURE-KEY-2026');
  const [unlockedDocId, setUnlockedDocId] = useState<string | null>(null);
  const [unlockedContent, setUnlockedContent] = useState<string | null>(null);
  const [decryptingId, setDecryptingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filter encrypted documents only
  const encryptedDocs = documents.filter((d) => d.isEncrypted);

  const handleQuickUnlock = async (doc: ArchiveDocument) => {
    if (unlockedDocId === doc.id) {
      setUnlockedDocId(null);
      setUnlockedContent(null);
      return;
    }

    setDecryptingId(doc.id);
    setErrorMsg(null);

    const res = await decryptDoc(doc.id, masterPassphrase);
    if (res.success && res.content) {
      setUnlockedDocId(doc.id);
      setUnlockedContent(res.content);
    } else {
      setErrorMsg(res.error || 'Kata sandi / Kunci enkripsi tidak cocok.');
    }
    setDecryptingId(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Security Banner - Black & Gold Tone */}
      <div className="bg-gradient-to-r from-slate-950 via-zinc-900 to-stone-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-500/20 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-bold mb-3 border border-amber-500/30">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>Kriptografi Kearsipan Standar Nasional • AES-GCM 256-Bit</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Brankas Digital Terenkripsi BUDIKA ARSIP
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Penyimpanan dokumen sensitif berkategori Rahasia & Sangat Rahasia Kementerian Haji dan Umrah RI (Kontrak Bilateral Masyair, Kuota Khusus, Dokumen Kepegawaian Pribadi, dan Laporan Hasil Pemeriksaan).
            Data terenkripsi secara kriptografis menggunakan algoritma AES-256 dengan derivasi kunci PBKDF2 (100.000 iterasi).
          </p>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Key Management Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-50 text-amber-800 border border-amber-200">
              <Key className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Kunci Dekripsi Kementerian Haji dan Umrah</h4>
              <p className="text-xs text-slate-500">
                Gunakan kunci master untuk membuka pratinjau dokumen terenkripsi secara langsung
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 max-w-md w-full">
            <input
              type="password"
              value={masterPassphrase}
              onChange={(e) => setMasterPassphrase(e.target.value)}
              placeholder="Masukkan kunci enkripsi..."
              className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-slate-900"
            />
            <span className="text-[11px] font-bold text-amber-900 bg-amber-100 px-2.5 py-2 rounded-xl border border-amber-300 shrink-0">
              Kunci Aktif
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
            {errorMsg}
          </div>
        )}
      </div>

      {/* List of Encrypted Documents */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Daftar Berkas Terenkripsi ({encryptedDocs.length} Berkas)
          </h3>
          <span className="text-xs text-slate-400">
            Perlindungan integritas SHA-256 aktif
          </span>
        </div>

        {encryptedDocs.length === 0 ? (
          <div className="bg-white p-10 rounded-2xl border border-slate-200 text-center">
            <Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-800">Belum ada dokumen terenkripsi</p>
            <p className="text-xs text-slate-500 mt-1">
              Saat mengunggah dokumen baru, centang opsi "Aktifkan Enkripsi AES-256".
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3.5">
            {encryptedDocs.map((doc) => {
              const isUnlocked = unlockedDocId === doc.id;
              const isBusy = decryptingId === doc.id;

              return (
                <div
                  key={doc.id}
                  className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-300 transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2.5 rounded-xl bg-slate-900 text-amber-400 shrink-0">
                        {isUnlocked ? <Unlock className="w-5 h-5 text-amber-400" /> : <Lock className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.2 rounded">
                            {doc.docNumber}
                          </span>
                          <span className="text-[11px] font-bold px-2 py-0.2 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                            {doc.securityLevel}
                          </span>
                          <span className="text-[11px] text-slate-500 font-medium">
                            {doc.category}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-900 mt-1">
                          {doc.title}
                        </h4>
                        <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                          {doc.summary}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleQuickUnlock(doc)}
                        disabled={isBusy}
                        className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                          isUnlocked
                            ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            : 'bg-slate-950 hover:bg-black text-amber-300 shadow-sm'
                        }`}
                      >
                        {isBusy ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : isUnlocked ? (
                          <Lock className="w-3.5 h-3.5" />
                        ) : (
                          <Unlock className="w-3.5 h-3.5" />
                        )}
                        <span>{isUnlocked ? 'Tutup Pratinjau' : 'Buka Dekripsi'}</span>
                      </button>

                      <button
                        onClick={() => setSelectedDocumentForDetail(doc)}
                        className="p-2 rounded-xl text-slate-500 hover:text-slate-950 hover:bg-slate-100"
                        title="Lihat Detail Lengkap"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Decrypted Content Box */}
                  {isUnlocked && (
                    <div className="mt-4 pt-3 border-t border-slate-100 text-xs animate-in fade-in">
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                        <div className="flex items-center justify-between text-slate-900 font-bold mb-1">
                          <span className="flex items-center gap-1 text-[11px] text-amber-700">
                            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" /> Pratinjau Teks Dokumen (Berhasil didekripsi)
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            SHA-256: {doc.sha256Hash.slice(0, 16)}...
                          </span>
                        </div>
                        <p className="text-slate-800 leading-relaxed font-sans whitespace-pre-wrap">
                          {unlockedContent || doc.summary}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
