import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import {
  CloudCheck,
  CloudOff,
  Cloud,
  RefreshCw,
  Download,
  Upload,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  HardDrive,
  Database,
  ExternalLink,
  HelpCircle,
  Copy,
  Check,
  Sparkles,
  X,
  ShieldAlert,
} from 'lucide-react';

export const GoogleDriveAndBackupView: React.FC = () => {
  const {
    isGoogleConnected,
    googleUser,
    connectGoogleDrive,
    connectSimulatedDrive,
    disconnectGoogleDrive,
    gdriveFolderName,
    isSyncingGDrive,
    syncAllToDrive,
    documents,
    logs,
    autoBackupEnabled,
    setAutoBackupEnabled,
    backupSchedule,
    setBackupSchedule,
    lastBackupTime,
    createBackupBundle,
    restoreBackupBundle,
  } = useArchive();

  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [backupSuccessMessage, setBackupSuccessMessage] = useState<string | null>(null);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [showOAuthHelpModal, setShowOAuthHelpModal] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectNotice, setConnectNotice] = useState<string | null>(null);

  const totalDocs = documents.length;
  const syncedDocs = documents.filter((d) => d.gdriveSynced).length;

  const userEmailToRegister = 'budikarabbani2@gmail.com';
  const gcpProjectId = 'gen-lang-client-0393597484';
  const gcpConsentUrl = `https://console.cloud.google.com/apis/credentials/consent?project=${gcpProjectId}`;

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(userEmailToRegister);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setConnectNotice(null);
    try {
      const ok = await connectGoogleDrive();
      if (!ok) {
        setConnectNotice(
          'Login belum selesai atau diblokir Google karena status OAuth masih Testing. Buka panduan solusi di bawah untuk menyelesaikannya dalam 1 menit.'
        );
      }
    } catch (err: any) {
      setConnectNotice(
        'Muncul penolakan Google: "Akses diblokir / Belum menyelesaikan verifikasi". Ikuti solusi 1 menit di bawah ini.'
      );
    } finally {
      setIsConnecting(false);
    }
  };

  const handleManualBackup = async () => {
    setIsCreatingBackup(true);
    setBackupSuccessMessage(null);

    const res = await createBackupBundle(isGoogleConnected);
    if (res.success && res.jsonString) {
      // Trigger automatic local download
      const blob = new Blob([res.jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Backup_BUDIKA_ARSIF_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setBackupSuccessMessage(
        `Pencadangan berhasil dibuat! Berkas diunduh ke komputer lokal${
          isGoogleConnected ? ' dan disalin ke Google Drive' : ''
        }.`
      );
    }
    setIsCreatingBackup(false);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setRestoreMessage(null);
    setRestoreError(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const confirmRestore = window.confirm(
          `Apakah Anda yakin ingin memulihkan data dari berkas "${file.name}"? Data arsip saat ini akan diselaraskan dengan cadangan.`
        );
        if (!confirmRestore) return;

        const res = await restoreBackupBundle(text);
        if (res.success) {
          setRestoreMessage(`Berhasil memulihkan ${res.restoredDocs} dokumen arsip ke sistem.`);
        } else {
          setRestoreError(res.error || 'Format berkas cadangan tidak sesuai.');
        }
      } catch (err: any) {
        setRestoreError(err.message || 'Gagal membaca berkas cadangan.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner: Gold & Black Theme */}
      <div className="bg-gradient-to-r from-slate-950 via-zinc-900 to-stone-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-500/20 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-bold mb-3 border border-amber-500/30">
            <Cloud className="w-3.5 h-3.5 text-amber-400" />
            <span>Penyimpanan Google Drive Resmi • Kementerian Haji dan Umrah RI</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Integrasi Google Drive & Pencadangan Otomatis
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Menyimpan salinan arsip kementerian langsung ke akun Google Drive dinas pada folder khusus{' '}
            <strong className="text-amber-300 font-mono bg-white/10 px-1.5 py-0.5 rounded">
              {gdriveFolderName}
            </strong>
            . Menjamin ketersediaan berkas 24/7 dan kepatuhan terhadap standar integritas kearsipan nasional tanpa biaya sewa server cloud tambahan.
          </p>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Special Callout: Google OAuth Blocked Guide */}
      <div className="bg-amber-50/80 border border-amber-300/80 rounded-3xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-2xl bg-amber-400 text-slate-950 shrink-0 mt-0.5 shadow-sm">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-extrabold text-slate-950">
                  Muncul Notifikasi "Akses Diblokir: Belum Menyelesaikan Proses Verifikasi Google"?
                </h4>
                <span className="text-[10px] font-black bg-slate-950 text-amber-300 px-2 py-0.5 rounded-full">
                  SOLUSI 1 MENIT
                </span>
              </div>
              <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                Ini adalah mekanisme keamanan standar Google karena aplikasi Anda berada dalam mode <strong>Testing (Pengujian)</strong> di Google Cloud.
                Google hanya mengizinkan akun yang terdaftar dalam daftar <strong>Test users</strong> untuk masuk.
              </p>

              <div className="mt-3 flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setShowOAuthHelpModal(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-300 shadow-xs transition-all active:scale-95"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Lihat Langkah Mengatasi (1 Menit)</span>
                </button>

                <a
                  href={gcpConsentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 shadow-xs transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-amber-600" />
                  <span>Buka Layar Persetujuan Google Cloud</span>
                </a>

                {!isGoogleConnected && (
                  <button
                    onClick={() => connectSimulatedDrive(userEmailToRegister)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xs transition-all active:scale-95"
                    title="Gunakan simulasi cloud drive langsung tanpa verifikasi Google"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Aktifkan Mode Uji Coba Cloud Drive Sekarang (Bypass)</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Google Drive Connection Card */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl ${isGoogleConnected ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-500'}`}>
              {isGoogleConnected ? <CloudCheck className="w-6 h-6 text-amber-600" /> : <CloudOff className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  {isGoogleConnected ? 'Google Drive Terhubung' : 'Google Drive Belum Terhubung'}
                </h3>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isGoogleConnected
                      ? 'bg-amber-100 text-amber-950 border border-amber-300 font-extrabold'
                      : 'bg-slate-100 text-slate-600 border border-slate-200'
                  }`}
                >
                  {isGoogleConnected ? 'ONLINE & SYNC' : 'DISCONNECTED'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {isGoogleConnected && googleUser
                  ? `Akun: ${googleUser.email || userEmailToRegister} • Izin Akses: Google Drive App Files (Folder: ${gdriveFolderName})`
                  : 'Hubungkan akun Google resmi untuk mengaktifkan sinkronisasi dokumen otomatis ke awan'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isGoogleConnected ? (
              <>
                <button
                  onClick={() => syncAllToDrive()}
                  disabled={isSyncingGDrive}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-300 shadow-xs transition-all active:scale-95"
                >
                  {isSyncingGDrive ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  ) : (
                    <RefreshCw className="w-4 h-4 text-amber-400" />
                  )}
                  <span>Sinkronkan Semua ({totalDocs - syncedDocs} Berkas)</span>
                </button>
                <button
                  onClick={disconnectGoogleDrive}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                >
                  Putuskan
                </button>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleConnectGoogle}
                  disabled={isConnecting}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-md active:scale-95 transition-all"
                >
                  {isConnecting ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  ) : (
                    <Cloud className="w-4 h-4 text-amber-400" />
                  )}
                  <span>Hubungkan Google Drive Sekarang</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {connectNotice && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{connectNotice}</span>
            </div>
            <button
              onClick={() => setShowOAuthHelpModal(true)}
              className="text-xs font-bold underline text-amber-900 hover:text-black shrink-0"
            >
              Panduan Solusi
            </button>
          </div>
        )}

        {/* Sync Progress Bar */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700">Status Sinkronisasi Berkas</span>
            <span className="font-bold text-slate-900">
              {syncedDocs} dari {totalDocs} berkas tersinkron ({totalDocs > 0 ? Math.round((syncedDocs / totalDocs) * 100) : 0}%)
            </span>
          </div>
          <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 rounded-full transition-all duration-500"
              style={{ width: `${totalDocs > 0 ? (syncedDocs / totalDocs) * 100 : 0}%` }}
            />
          </div>
        </div>
      </div>

      {/* Automated Backup Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Auto Backup Configuration */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200">
              <Database className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Konfigurasi Cadangan Otomatis</h3>
              <p className="text-xs text-slate-400">
                Pencadangan rutin menjaga keutuhan data terhadap bencana sistem
              </p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="font-bold text-slate-800">Status Pencadangan Otomatis</span>
              <input
                type="checkbox"
                checked={autoBackupEnabled}
                onChange={(e) => setAutoBackupEnabled(e.target.checked)}
                className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
              />
            </label>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Jadwal Siklus Pencadangan:
              </label>
              <select
                value={backupSchedule}
                onChange={(e) => setBackupSchedule(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
              >
                <option value="REALTIME">Real-Time (Snapshot Setiap Ada Perubahan Dokumen)</option>
                <option value="HOURLY">Per Jam (Setiap 60 Menit)</option>
                <option value="DAILY">Harian (Setiap Hari Pukul 00:00 WIB)</option>
              </select>
            </div>

            <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-200">
              Pencadangan Terakhir:{' '}
              <strong className="text-slate-800">
                {lastBackupTime ? new Date(lastBackupTime).toLocaleString('id-ID') : 'Belum pernah'}
              </strong>
            </div>
          </div>

          <button
            onClick={handleManualBackup}
            disabled={isCreatingBackup}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-slate-950 hover:bg-black text-amber-400 shadow-xs active:scale-95 transition-all"
          >
            {isCreatingBackup ? (
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <Download className="w-4 h-4 text-amber-400" />
            )}
            <span>Cadangkan & Unduh Snapshot Sekarang (.JSON)</span>
          </button>

          {backupSuccessMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{backupSuccessMessage}</span>
            </div>
          )}
        </div>

        {/* Right: Restore from Backup */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-slate-100 text-slate-800 border border-slate-300">
              <HardDrive className="w-5 h-5 text-slate-700" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Pemulihan Data (Restore Snapshot)</h3>
              <p className="text-xs text-slate-400">
                Pulihkan arsip dan log audit dari berkas cadangan JSON yang valid
              </p>
            </div>
          </div>

          <div className="border-2 border-dashed border-slate-300 hover:border-amber-400 rounded-2xl p-5 text-center bg-slate-50/50 transition-colors">
            <input
              type="file"
              id="restore-upload"
              accept=".json"
              onChange={handleRestoreFile}
              className="hidden"
            />
            <label htmlFor="restore-upload" className="cursor-pointer flex flex-col items-center justify-center">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2 border border-amber-200">
                <Upload className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                Pilih Berkas Cadangan (.JSON)
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                Pastikan berkas berasal dari ekspor BUDIKA ARSIP
              </span>
            </label>
          </div>

          {restoreMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{restoreMessage}</span>
            </div>
          )}

          {restoreError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{restoreError}</span>
            </div>
          )}
        </div>
      </div>

      {/* Free Tier, Storage Upgrade & Gemini Guide Section */}
      <div className="bg-gradient-to-br from-slate-950 via-zinc-900 to-stone-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-amber-500/20 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-400 text-slate-950 font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                Panduan Biaya & Kapasitas Penyimpanan
              </span>
              <h3 className="text-base sm:text-lg font-black text-white">
                Skema 100% Gratis & Cara Memperbesar Google Drive / Gemini Pro
              </h3>
            </div>
          </div>
          <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-400/30 shrink-0">
            Biaya Aplikasi: Rp 0 (GRATIS)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Card 1: App is 100% Free */}
          <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
              <CheckCircle2 className="w-4 h-4" />
              1. Aplikasi BUDIKA ARSIP
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Aplikasi ini <strong>100% gratis</strong> tanpa biaya lisensi per pegawai, tanpa biaya langganan bulanan aplikasi, dan tanpa biaya sewa server database terpisah. Dokumen tersimpan aman di peramban Anda dan terhubung langsung ke akun Google Drive dinas.
            </p>
            <div className="text-[10px] text-amber-300 bg-amber-400/10 p-2 rounded-xl border border-amber-400/20">
              ✓ Tidak ada biaya langganan paket software apapun.
            </div>
          </div>

          {/* Card 2: Google Drive Storage */}
          <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
              <Cloud className="w-4 h-4" />
              2. Kapasitas Google Drive
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Setiap akun Google gratis mendapatkan <strong>15 GB</strong> (cukup untuk menampung ~15.000 dokumen PDF dinas).
            </p>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              <strong>Cara dapat Drive lebih besar:</strong>
            </p>
            <ul className="space-y-1 text-[10px] text-slate-300">
              <li>• <strong>Opsi A (Gratis):</strong> Masuk menggunakan akun Google Workspace instansi Kementerian (misal: <code>@haji.go.id</code>) yang sudah memiliki kuota dinas sangat besar.</li>
              <li>• <strong>Opsi B:</strong> Berlangganan langsung <strong>Google One</strong> resmi pada akun Google Anda: 100 GB (~Rp 26.900/bln) atau 2 TB (~Rp 135.000/bln).</li>
            </ul>
          </div>

          {/* Card 3: Gemini AI Model */}
          <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
              <Database className="w-4 h-4" />
              3. AI Deteksi Kategori
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Secara default sistem menggunakan model <strong>Gemini 3.8 Flash</strong> yang memiliki <strong>Free Tier (Gratis)</strong> di Google AI Studio hingga 1.500 pemindaian dokumen per hari tanpa biaya.
            </p>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              <strong>Jika ingin Gemini Pro:</strong> Cukup hubungkan metode pembayaran (Billing) di Google Cloud / AI Studio Settings untuk mengaktifkan Gemini Pro dengan skema <em>Pay-as-you-go</em> (hanya bayar beberapa rupiah per dokumen yang dianalisis).
            </p>
          </div>
        </div>

        {/* Footer info banner */}
        <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Folder arsip di Google Drive Anda: <strong>{gdriveFolderName}</strong></span>
          </div>
          <a
            href="https://one.google.com/about"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-amber-400 border border-amber-500/30 font-bold text-[11px] transition-colors shrink-0"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Cek Paket Resmi Google One
          </a>
        </div>
      </div>

      {/* POPUP MODAL: Panduan Mengatasi Akses Diblokir Google */}
      {showOAuthHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-5 text-slate-800">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200">
                  <ShieldAlert className="w-6 h-6 text-amber-700" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-950">
                    Cara Mengatasi "Akses Diblokir oleh Google"
                  </h3>
                  <p className="text-xs text-slate-500">
                    Hanya butuh 1 menit di Google Cloud Console (100% Gratis)
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowOAuthHelpModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Explanation */}
            <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-950 space-y-1.5">
              <p className="font-bold">Kenapa Muncul Notifikasi Ini?</p>
              <p className="text-[11px] text-amber-900 leading-relaxed">
                Google memiliki aturan keamanan ketat: aplikasi yang meminta izin Google Drive dan statusnya masih dalam tahap pengujian (<strong>Testing</strong>) hanya boleh diakses oleh email yang telah didaftarkan sebagai <strong>"Test Users" (Pengguna Uji Coba)</strong>.
              </p>
            </div>

            {/* Step by step */}
            <div className="space-y-3 text-xs">
              <h4 className="font-extrabold text-slate-950 text-sm">
                Ikuti 3 Langkah Mudah Ini:
              </h4>

              {/* Step 1 */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-950 text-amber-300 flex items-center justify-center text-[10px]">
                      1
                    </span>
                    Buka Halaman Layar Persetujuan OAuth di Google Cloud
                  </span>
                  <a
                    href={gcpConsentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 hover:underline"
                  >
                    <span>Klik Buka Konsol</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <p className="text-[11px] text-slate-500">
                  Atau kunjungi tautan: <code className="bg-slate-200 px-1 py-0.5 rounded text-[10px] break-all">{gcpConsentUrl}</code>
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-950 text-amber-300 flex items-center justify-center text-[10px]">
                    2
                  </span>
                  Tambahkan Email Anda ke Bagian "Test users"
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Gulir (*scroll*) ke bawah sampai menemukan bagian <strong>Test users (Pengguna uji coba)</strong>, lalu klik tombol <strong>+ ADD USERS (+ TAMBAH PENGGUNA)</strong>.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    readOnly
                    value={userEmailToRegister}
                    className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl font-mono text-slate-900 font-bold"
                  />
                  <button
                    onClick={handleCopyEmail}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-950 text-amber-300 hover:bg-black transition-all"
                  >
                    {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedEmail ? 'Tersalin!' : 'Salin Email'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Ketikkan atau tempel email Anda di atas, lalu klik <strong>SAVE (SIMPAN)</strong>.
                </p>
              </div>

              {/* Step 3 */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-950 text-amber-300 flex items-center justify-center text-[10px]">
                    3
                  </span>
                  Kembali ke Aplikasi & Lewati Peringatan Google
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Setelah email disimpan di Google Cloud, klik tombol <strong>"Hubungkan Google Drive Sekarang"</strong> lagi. Jika muncul jendela bertuliskan <em>"Google hasn't verified this app" (Google belum memverifikasi aplikasi ini)</em>:
                </p>
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-[11px] text-slate-700 space-y-1">
                  <p>1. Klik tautan teks kecil <strong>"Advanced" (Lanjutan)</strong> di pojok kiri bawah.</p>
                  <p>2. Klik <strong>"Go to {gcpProjectId}.firebaseapp.com (unsafe)"</strong> atau <strong>"Buka ... (tidak aman)"</strong>.</p>
                  <p>3. Klik <strong>"Continue" (Lanjutkan)</strong> untuk mengizinkan folder <code>{gdriveFolderName}</code>.</p>
                </div>
              </div>
            </div>

            {/* Quick Option Bypass */}
            <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-[11px] text-slate-500">
                Ingin langsung coba tanpa buka Google Cloud?
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    connectSimulatedDrive(userEmailToRegister);
                    setShowOAuthHelpModal(false);
                  }}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-sm transition-all"
                >
                  Aktifkan Mode Uji Coba (Bypass Sekarang)
                </button>
                <button
                  onClick={() => setShowOAuthHelpModal(false)}
                  className="px-4 py-2 text-xs font-bold rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
