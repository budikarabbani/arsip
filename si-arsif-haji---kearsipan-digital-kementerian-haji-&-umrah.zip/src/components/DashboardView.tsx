import React, { useState } from 'react';
import { useArchive } from '../context/ArchiveContext';
import {
  FileText,
  Lock,
  CloudCheck,
  Clock,
  ShieldCheck,
  UserCheck,
  Printer,
  ChevronRight,
  Sparkles,
  ArrowUpRight,
  AlertCircle,
  CheckCircle2,
  Building,
  Users,
} from 'lucide-react';
import { ArchiveCategory, SecurityLevel } from '../types/archive';

export const DashboardView: React.FC = () => {
  const {
    documents,
    logs,
    users,
    currentUser,
    isGoogleConnected,
    setActiveTab,
    setIsUploadModalOpen,
  } = useArchive();

  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Real-time calculation of statistics
  const totalDocs = documents.length;
  const encryptedDocs = documents.filter((d) => d.isEncrypted).length;
  const pendingDocs = documents.filter((d) => d.status === 'Menunggu Verifikasi').length;
  const archivedDocs = documents.filter((d) => d.status === 'Diarsipkan').length;
  const gdriveSyncedDocs = documents.filter((d) => d.gdriveSynced).length;
  const personnelDocs = documents.filter((d) => d.isPersonnelFile).length;

  // Category breakdown
  const categoryCounts: Record<ArchiveCategory, number> = {
    'Regulasi & Kebijakan Haji': 0,
    'Kepegawaian & Petugas Haji': 0,
    'Operasional Kuota & Paspor Jemaah': 0,
    'Layanan Akomodasi & Masyair': 0,
    'Keuangan & BPIH': 0,
    'Kerjasama Bilateral & Syarikah': 0,
    'Surat Dinas & Disposisi': 0,
    'Umum & Publikasi': 0,
  };

  documents.forEach((d) => {
    if (categoryCounts[d.category] !== undefined) {
      categoryCounts[d.category]++;
    }
  });

  // Security levels breakdown
  const securityCounts: Record<SecurityLevel, number> = {
    Publik: 0,
    Terbatas: 0,
    Rahasia: 0,
    'Sangat Rahasia': 0,
  };

  documents.forEach((d) => {
    if (securityCounts[d.securityLevel] !== undefined) {
      securityCounts[d.securityLevel]++;
    }
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner / Welcome Card - Gold & Black theme */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-zinc-900 to-stone-950 text-white p-6 sm:p-8 shadow-xl border border-amber-500/20 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-bold mb-3 border border-amber-500/30">
            <Building className="w-3.5 h-3.5" />
            <span>Kementerian Haji dan Umrah Republik Indonesia • BUDIKA ARSIP</span>
          </div>
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-white tracking-tight">
            Selamat Datang, {currentUser.name}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Sistem tata kelola kearsipan digital resmi Kementerian Haji dan Umrah RI.
            Dilengkapi enkripsi AES-256 untuk berkas rahasia, deteksi kategori cerdas AI,
            dan integrasi cadangan awan Google Drive yang aman dan praktis.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-5">
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-md transition-all active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              Unggah Dokumen Baru
            </button>
            <button
              onClick={() => setActiveTab('admin_users')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm border border-white/20 transition-all backdrop-blur-xs"
            >
              <Users className="w-4 h-4 text-amber-300" />
              Panel Pengguna ({users.length} Akun)
            </button>
            <button
              onClick={() => setIsPrintModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-semibold text-xs sm:text-sm border border-white/10 transition-all"
            >
              <Printer className="w-4 h-4" />
              Cetak Laporan Kinerja
            </button>
          </div>
        </div>

        {/* Decorative background geometry */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-5 pointer-events-none flex items-center justify-center">
          <ShieldCheck className="w-96 h-96 -mr-16 text-amber-400" />
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* Total Documents */}
        <div
          onClick={() => setActiveTab('archives')}
          className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Total Arsip Tersimpan</span>
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5 text-amber-700" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-950">{totalDocs}</span>
            <span className="text-xs text-slate-400 font-semibold">berkas</span>
          </div>
          <div className="mt-2 flex items-center text-[11px] text-emerald-800 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" /> {archivedDocs} berstatus definitif
          </div>
        </div>

        {/* Encrypted Documents */}
        <div
          onClick={() => setActiveTab('vault')}
          className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Berkas Terenkripsi</span>
            <div className="p-2.5 rounded-2xl bg-slate-100 text-slate-800 border border-slate-200 group-hover:scale-110 transition-transform">
              <Lock className="w-5 h-5 text-amber-600" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-950">{encryptedDocs}</span>
            <span className="text-xs text-amber-950 font-black bg-amber-100 px-1.5 py-0.5 rounded-md border border-amber-300">
              AES-256
            </span>
          </div>
          <div className="mt-2 flex items-center text-[11px] text-slate-700 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 mr-1 text-amber-600" /> Kriptografi tingkat tinggi
          </div>
        </div>

        {/* Pending Verification */}
        <div
          onClick={() => setActiveTab('archives')}
          className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Perlu Verifikasi</span>
            <div className="p-2.5 rounded-2xl bg-stone-100 text-stone-800 border border-stone-200 group-hover:scale-110 transition-transform">
              <Clock className="w-5 h-5 text-amber-600" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-950">{pendingDocs}</span>
            <span className="text-xs text-slate-400 font-semibold">berkas</span>
          </div>
          <div className="mt-2 flex items-center text-[11px] text-amber-800 font-bold">
            <AlertCircle className="w-3.5 h-3.5 mr-1 text-amber-600" /> Menunggu disposisi
          </div>
        </div>

        {/* Google Drive Sync */}
        <div
          onClick={() => setActiveTab('backup')}
          className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Google Drive Dinas</span>
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200 group-hover:scale-110 transition-transform">
              <CloudCheck className="w-5 h-5 text-amber-700" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-950">
              {gdriveSyncedDocs}/{totalDocs}
            </span>
            <span className="text-xs text-amber-800 font-bold">Tersinkron</span>
          </div>
          <div className="mt-2 flex items-center text-[11px] text-slate-600 font-medium">
            {isGoogleConnected ? '● Folder BUDIKA-ARSIF-HAJI' : '○ Klik untuk hubungkan'}
          </div>
        </div>
      </div>

      {/* Main Monitoring Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Category Breakdown & Daily Performance */}
        <div className="lg:col-span-2 space-y-6">
          {/* Distribution by Category */}
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-black text-slate-950">
                  Distribusi Kategori Arsip Kementerian Haji & Umrah
                </h3>
                <p className="text-xs text-slate-400">
                  Pengelompokan dokumen berdasarkan nomenklatur kementerian
                </p>
              </div>
              <button
                onClick={() => setActiveTab('archives')}
                className="text-xs font-bold text-amber-800 hover:text-amber-950 inline-flex items-center gap-1"
              >
                Lihat Semua <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {(Object.keys(categoryCounts) as ArchiveCategory[]).map((cat) => {
                const count = categoryCounts[cat];
                const percentage = totalDocs > 0 ? Math.round((count / totalDocs) * 100) : 0;

                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700">{cat}</span>
                      <span className="font-bold text-slate-950">
                        {count} berkas ({percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-slate-900 to-amber-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.max(percentage, 4)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Daily Administration Performance Report */}
          <div className="bg-gradient-to-br from-slate-950 via-zinc-900 to-black text-white p-5 sm:p-6 rounded-3xl shadow-md border border-amber-500/20">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider">
                  Kinerja Kearsipan Harian
                </span>
                <h3 className="text-base font-black text-white mt-1">
                  Laporan Pelayanan Administrasi Kearsipan
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Tanggal: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </p>
              </div>
              <button
                onClick={() => setIsPrintModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl transition-all"
              >
                <Printer className="w-3.5 h-3.5 text-slate-950" />
                Cetak Format Resmi
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-white/10">
              <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                <span className="text-[11px] text-slate-400">Efisiensi Arsip</span>
                <p className="text-lg font-black text-amber-300 mt-1">99.1%</p>
                <span className="text-[10px] text-slate-400">Digital Archive</span>
              </div>
              <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                <span className="text-[11px] text-slate-400">Enkripsi Berkas</span>
                <p className="text-lg font-black text-white mt-1">100%</p>
                <span className="text-[10px] text-amber-400">AES-GCM 256</span>
              </div>
              <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                <span className="text-[11px] text-slate-400">Audit Checksum</span>
                <p className="text-lg font-black text-amber-300 mt-1">VALID</p>
                <span className="text-[10px] text-slate-400">SHA-256 Verified</span>
              </div>
              <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                <span className="text-[11px] text-slate-400">Cloud Sync</span>
                <p className="text-lg font-black text-white mt-1">AKTIF</p>
                <span className="text-[10px] text-emerald-400">Google Drive</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col */}
        <div className="space-y-6">
          {/* Security Classification Card */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
            <h3 className="text-sm font-black text-slate-950 mb-1">
              Klasifikasi Keamanan Informasi
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Klasifikasi keamanan data Kementerian Haji dan Umrah RI
            </p>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-bold text-slate-500 uppercase">Publik</span>
                <p className="text-lg font-black text-slate-900 mt-1">{securityCounts['Publik']}</p>
                <span className="text-[10px] text-slate-400">Terbuka</span>
              </div>
              <div className="p-3 rounded-2xl bg-zinc-50 border border-zinc-200">
                <span className="text-[11px] font-bold text-zinc-700 uppercase">Terbatas</span>
                <p className="text-lg font-black text-zinc-900 mt-1">{securityCounts['Terbatas']}</p>
                <span className="text-[10px] text-zinc-500">Internal Pegawai</span>
              </div>
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200">
                <span className="text-[11px] font-bold text-amber-800 uppercase">Rahasia</span>
                <p className="text-lg font-black text-amber-950 mt-1">{securityCounts['Rahasia']}</p>
                <span className="text-[10px] text-amber-700">AES-256</span>
              </div>
              <div className="p-3 rounded-2xl bg-red-50 border border-red-200">
                <span className="text-[11px] font-bold text-red-800 uppercase">Sangat Rahasia</span>
                <p className="text-lg font-black text-red-950 mt-1">{securityCounts['Sangat Rahasia']}</p>
                <span className="text-[10px] text-red-700">Diplomatik / Pimpinan</span>
              </div>
            </div>
          </div>

          {/* Quick Personnel Access shortcut */}
          <div
            onClick={() => setActiveTab('personnel')}
            className="p-5 rounded-3xl bg-gradient-to-br from-slate-950 via-zinc-900 to-black text-white cursor-pointer shadow-md hover:shadow-lg transition-all border border-amber-500/20"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-400/20 text-amber-400">
                  <UserCheck className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Dossier Kepegawaian Saya</h4>
                  <p className="text-[11px] text-slate-400">Akses Berkas Pribadi</p>
                </div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-amber-400" />
            </div>
            <p className="text-xs text-slate-300 mt-3 leading-relaxed">
              Temukan dan simpan SK Kenaikan Pangkat, Sertifikat Bimtek PPIH Arab Saudi, Paspor Dinas, dan SKP Anda secara rapi.
            </p>
          </div>

          {/* Quick Admin Panel Shortcut */}
          <div
            onClick={() => setActiveTab('admin_users')}
            className="p-4 rounded-3xl bg-amber-50 border border-amber-300 cursor-pointer hover:bg-amber-100 transition-all flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-400 rounded-xl text-slate-950 font-bold">
                <Users className="w-4 h-4 text-slate-950" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-950">Panel Admin & Pengguna</h4>
                <p className="text-[11px] text-slate-600">Daftarkan pegawai dengan email resmi</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-700" />
          </div>
        </div>
      </div>

      {/* Official Daily Administration Report Print Modal */}
      {isPrintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Header of official report */}
            <div className="border-b-2 border-slate-950 pb-4 text-center">
              <p className="text-xs font-black tracking-widest text-amber-700 uppercase">
                KEMENTERIAN HAJI DAN UMRAH REPUBLIK INDONESIA
              </p>
              <h2 className="text-base sm:text-lg font-black text-slate-950 mt-1">
                BUDIKA ARSIP DIGITAL • LAPORAN KINERJA HARIAN
              </h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Tanggal: {new Date().toLocaleString('id-ID')} • Operator: {currentUser.name} (NIP: {currentUser.nip})
              </p>
            </div>

            {/* Content summary table */}
            <div className="py-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-slate-400">Total Arsip Terdaftar:</span>
                  <p className="font-extrabold text-sm text-slate-900">{totalDocs} Berkas</p>
                </div>
                <div>
                  <span className="text-slate-400">Arsip Terenkripsi (AES-256):</span>
                  <p className="font-extrabold text-sm text-amber-900">{encryptedDocs} Berkas Rahasia</p>
                </div>
                <div>
                  <span className="text-slate-400">Arsip Definitif:</span>
                  <p className="font-extrabold text-sm text-emerald-900">{archivedDocs} Berkas</p>
                </div>
                <div>
                  <span className="text-slate-400">Tersinkronisasi Google Drive:</span>
                  <p className="font-extrabold text-sm text-slate-900">{gdriveSyncedDocs} Berkas</p>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2">Daftar Berkas Terkini:</h4>
                <div className="border border-slate-200 rounded-2xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-[11px] font-bold text-slate-700">
                      <tr>
                        <th className="p-2">No. Surat</th>
                        <th className="p-2">Judul Dokumen</th>
                        <th className="p-2">Kategori</th>
                        <th className="p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-[11px]">
                      {documents.slice(0, 5).map((doc) => (
                        <tr key={doc.id}>
                          <td className="p-2 font-mono">{doc.docNumber}</td>
                          <td className="p-2 font-medium truncate max-w-[200px]">{doc.title}</td>
                          <td className="p-2">{doc.category}</td>
                          <td className="p-2 font-bold text-slate-900">{doc.status}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 text-slate-900">
                <p className="font-bold text-[11px]">Pernyataan Kepatuhan Keamanan & Kerahasiaan:</p>
                <p className="text-[10px] mt-0.5 leading-relaxed text-slate-700">
                  Seluruh data berkas kepegawaian dan kontrak dinas tersimpan dalam enkripsi kriptografi AES-GCM 256-bit dan diaudit berkala dengan SHA-256. Sistem berjalan dengan aman dan mematuhi tata naskah dinas Kementerian Haji dan Umrah Republik Indonesia.
                </p>
              </div>
            </div>

            {/* Modal actions */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                onClick={() => setIsPrintModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                Tutup
              </button>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl bg-slate-950 text-amber-400 hover:bg-black"
              >
                <Printer className="w-3.5 h-3.5 text-amber-400" />
                Cetak Dokumen Laporan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
