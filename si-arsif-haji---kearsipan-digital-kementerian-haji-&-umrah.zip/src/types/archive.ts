export type ArchiveCategory =
  | 'Regulasi & Kebijakan Haji'
  | 'Kepegawaian & Petugas Haji'
  | 'Operasional Kuota & Paspor Jemaah'
  | 'Layanan Akomodasi & Masyair'
  | 'Keuangan & BPIH'
  | 'Kerjasama Bilateral & Syarikah'
  | 'Surat Dinas & Disposisi'
  | 'Umum & Publikasi';

export type SecurityLevel = 'Publik' | 'Terbatas' | 'Rahasia' | 'Sangat Rahasia';

export type DocumentStatus =
  | 'Draf'
  | 'Menunggu Verifikasi'
  | 'Diverifikasi'
  | 'Diarsipkan'
  | 'Ditolak';

export type PersonnelType =
  | 'SK_PNS'
  | 'SK_KENAIKAN_PANGKAT'
  | 'SERTIFIKAT_PPIH'
  | 'SURAT_TUGAS_ARAB_SAUDI'
  | 'PASPOR_DINAS'
  | 'SKP_KINERJA'
  | 'IJAZAH'
  | 'LAINNYA';

export type UserRole =
  | 'SUPER_ADMIN'
  | 'ARSIPARIS'
  | 'PEJABAT_VERIFIKATOR'
  | 'PEGAWAI'
  | 'AUDITOR';

export interface UserProfile {
  id: string;
  name: string;
  nip: string;
  email: string;
  phone: string;
  role: UserRole;
  roleTitle: string;
  unit: string;
  avatar: string;
  createdAt: string;
  isActive: boolean;
}

export interface ArchiveDocument {
  id: string;
  title: string;
  docNumber: string;
  category: ArchiveCategory;
  subCategory: string;
  securityLevel: SecurityLevel;
  status: DocumentStatus;
  isEncrypted: boolean;
  encryptionIv?: string;
  encryptionSalt?: string;
  encryptedContent?: string;
  fileData?: string; // base64 or raw text preview
  fileName: string;
  fileType: string;
  fileSize: number; // in bytes
  sha256Hash: string;
  uploadDate: string; // ISO String
  year: number;
  retentionExpiry: string; // Date string (e.g. 2031-12-31)
  retentionYears: number;
  retentionAction: 'Permanen' | 'Musnah' | 'Dinilai Kembali';
  ownerNip: string;
  ownerName: string;
  ownerEmail?: string;
  ownerUnit: string;
  isPersonnelFile: boolean;
  personnelType?: PersonnelType;
  personnelOwnerNip?: string;
  personnelOwnerName?: string;
  personnelOwnerEmail?: string;
  summary: string;
  keywords: string[];
  aiClassified: boolean;
  aiReasoning?: string;
  notes?: string;
  gdriveSynced: boolean;
  gdriveFileId?: string;
  gdriveLink?: string;
  lastVerifiedBy?: string;
  lastVerifiedAt?: string;
  dispositionNotes?: string;
}

export type ActionType =
  | 'LOGIN'
  | 'LOGOUT'
  | 'UPLOAD'
  | 'VIEW'
  | 'ENCRYPT'
  | 'DECRYPT'
  | 'VERIFY'
  | 'APPROVE'
  | 'REJECT'
  | 'DISPOSITION'
  | 'EXPORT'
  | 'BACKUP'
  | 'RESTORE'
  | 'DELETE'
  | 'BULK_DELETE'
  | 'GDRIVE_SYNC'
  | 'ROLE_CHANGE'
  | 'USER_CREATE'
  | 'USER_UPDATE'
  | 'USER_DELETE';

export interface ActivityLog {
  id: string;
  timestamp: string;
  user: {
    nip: string;
    name: string;
    email?: string;
    role: UserRole;
  };
  action: ActionType;
  targetId?: string;
  targetTitle?: string;
  status: 'SUCCESS' | 'WARNING' | 'DENIED';
  ipAddress: string;
  device: string;
  details: string;
  hash: string;
}

export interface NotificationItem {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  type: 'STATUS_CHANGE' | 'SECURITY' | 'BACKUP' | 'GDRIVE' | 'USER_MGMT';
  read: boolean;
  docId?: string;
  recipientEmail?: string;
  channel?: 'IN_APP' | 'EMAIL' | 'WHATSAPP';
}
