import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  ArchiveDocument,
  ActivityLog,
  UserProfile,
  UserRole,
  DocumentStatus,
  ActionType,
  NotificationItem,
  ArchiveCategory,
} from '../types/archive';
import {
  SYSTEM_USERS,
  INITIAL_DOCUMENTS,
  INITIAL_LOGS,
  INITIAL_NOTIFICATIONS,
} from '../data/initialData';
import {
  encryptDocument,
  decryptDocument,
  generateAuditHash,
  computeSHA256,
} from '../services/crypto';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  getAccessToken,
} from '../services/firebase';
import {
  uploadToGoogleDrive,
  getOrCreateAppFolder,
  APP_FOLDER_NAME,
} from '../services/gdrive';
import { User } from 'firebase/auth';

interface ArchiveContextType {
  // Current user & User Management (Panel Admin)
  currentUser: UserProfile;
  users: UserProfile[];
  switchRole: (role: UserRole) => void;
  switchUser: (userId: string) => void;
  registerUser: (
    userData: Omit<UserProfile, 'id' | 'createdAt'>
  ) => { success: boolean; user?: UserProfile; error?: string };
  updateUser: (
    userId: string,
    userData: Partial<UserProfile>
  ) => { success: boolean; error?: string };
  deleteUser: (userId: string) => { success: boolean; error?: string };

  // Google Drive
  isGoogleConnected: boolean;
  googleUser: User | null;
  connectGoogleDrive: () => Promise<boolean>;
  connectSimulatedDrive: (email?: string) => void;
  disconnectGoogleDrive: () => Promise<void>;
  gdriveFolderName: string;
  isSyncingGDrive: boolean;
  lastGDriveSync: string | null;
  syncDocumentToDrive: (docId: string) => Promise<{ success: boolean; error?: string }>;
  syncAllToDrive: () => Promise<{ success: boolean; count: number; error?: string }>;

  // Documents
  documents: ArchiveDocument[];
  addDocument: (
    docData: Omit<ArchiveDocument, 'id' | 'uploadDate' | 'sha256Hash' | 'gdriveSynced'>,
    plainContent?: string,
    passphrase?: string
  ) => Promise<{ success: boolean; docId?: string; error?: string }>;
  updateDocumentStatus: (
    docId: string,
    status: DocumentStatus,
    dispositionNotes?: string
  ) => Promise<boolean>;
  deleteDocument: (docId: string) => Promise<boolean>;
  bulkDeleteDocuments: (docIds: string[]) => Promise<{ success: boolean; count: number }>;
  decryptDoc: (
    docId: string,
    passphrase: string
  ) => Promise<{ success: boolean; content?: string; error?: string }>;

  // Activity Logs
  logs: ActivityLog[];
  logAction: (
    action: ActionType,
    targetId?: string,
    targetTitle?: string,
    details?: string,
    status?: 'SUCCESS' | 'WARNING' | 'DENIED'
  ) => void;
  exportLogsToCSV: () => void;

  // Notifications
  notifications: NotificationItem[];
  markNotifAsRead: (id: string) => void;
  markAllNotifsRead: () => void;
  triggerStatusNotification: (
    doc: ArchiveDocument,
    newStatus: DocumentStatus,
    notes?: string
  ) => void;

  // Backup & Restore
  autoBackupEnabled: boolean;
  setAutoBackupEnabled: (val: boolean) => void;
  backupSchedule: 'HOURLY' | 'DAILY' | 'REALTIME';
  setBackupSchedule: (val: 'HOURLY' | 'DAILY' | 'REALTIME') => void;
  lastBackupTime: string | null;
  createBackupBundle: (toGoogleDrive?: boolean) => Promise<{ success: boolean; jsonString?: string; error?: string }>;
  restoreBackupBundle: (jsonString: string) => Promise<{ success: boolean; restoredDocs: number; error?: string }>;

  // Navigation & Search State
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedDocumentForDetail: ArchiveDocument | null;
  setSelectedDocumentForDetail: (doc: ArchiveDocument | null) => void;
  isUploadModalOpen: boolean;
  setIsUploadModalOpen: (open: boolean) => void;
  uploadInitialPersonnelOnly: boolean;
  setUploadInitialPersonnelOnly: (val: boolean) => void;
}

const ArchiveContext = createContext<ArchiveContextType | undefined>(undefined);

const STORAGE_DOCS_KEY = 'budika_arsip_docs_v3';
const STORAGE_LOGS_KEY = 'budika_arsip_logs_v3';
const STORAGE_NOTIF_KEY = 'budika_arsip_notif_v3';
const STORAGE_USERS_KEY = 'budika_arsip_users_v3';
const STORAGE_CURR_USER_KEY = 'budika_arsip_curr_user_v3';

export const ArchiveProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Users list (Admin panel)
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_USERS_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return SYSTEM_USERS;
  });

  // Current logged in user
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const savedUserId = localStorage.getItem(STORAGE_CURR_USER_KEY);
    if (savedUserId) {
      const found = SYSTEM_USERS.find((u) => u.id === savedUserId);
      if (found) return found;
    }
    return SYSTEM_USERS[0]; // Budika Rabbani (Admin Utama)
  });

  // Google Drive state
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [isGoogleConnected, setIsGoogleConnected] = useState<boolean>(false);
  const [isSyncingGDrive, setIsSyncingGDrive] = useState<boolean>(false);
  const [lastGDriveSync, setLastGDriveSync] = useState<string | null>(null);

  // Documents state
  const [documents, setDocuments] = useState<ArchiveDocument[]>(() => {
    const saved = localStorage.getItem(STORAGE_DOCS_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return INITIAL_DOCUMENTS;
  });

  // Logs state
  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_LOGS_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return INITIAL_LOGS;
  });

  // Notifications state
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_NOTIF_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return INITIAL_NOTIFICATIONS;
  });

  // Backup state
  const [autoBackupEnabled, setAutoBackupEnabled] = useState<boolean>(true);
  const [backupSchedule, setBackupSchedule] = useState<'HOURLY' | 'DAILY' | 'REALTIME'>('DAILY');
  const [lastBackupTime, setLastBackupTime] = useState<string | null>('2026-03-25T16:25:12Z');

  // UI state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedDocumentForDetail, setSelectedDocumentForDetail] = useState<ArchiveDocument | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [uploadInitialPersonnelOnly, setUploadInitialPersonnelOnly] = useState<boolean>(false);

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_CURR_USER_KEY, currentUser.id);
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_DOCS_KEY, JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_LOGS_KEY, JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_NOTIF_KEY, JSON.stringify(notifications));
  }, [notifications]);

  // Initialize Firebase Auth listener on startup
  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => {
        setGoogleUser(user);
        setIsGoogleConnected(true);
      },
      () => {
        setGoogleUser(null);
        setIsGoogleConnected(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // Log action helper
  const logAction = useCallback(
    (
      action: ActionType,
      targetId?: string,
      targetTitle?: string,
      details?: string,
      status: 'SUCCESS' | 'WARNING' | 'DENIED' = 'SUCCESS'
    ) => {
      const now = new Date().toISOString();
      const hash = generateAuditHash(now, currentUser.nip, action, targetId);
      const newLog: ActivityLog = {
        id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: now,
        user: {
          nip: currentUser.nip,
          name: currentUser.name,
          email: currentUser.email,
          role: currentUser.role,
        },
        action,
        targetId,
        targetTitle,
        status,
        ipAddress: '10.20.12.' + Math.floor(10 + Math.random() * 80) + ' (Jaringan Kantor Kementerian Haji)',
        device: 'Web Browser Client',
        details: details || `Aksi ${action} dilakukan oleh ${currentUser.name}`,
        hash,
      };

      setLogs((prev) => [newLog, ...prev]);
    },
    [currentUser]
  );

  // Role & User Switching
  const switchRole = useCallback(
    (role: UserRole) => {
      const targetUser = users.find((u) => u.role === role);
      if (targetUser) {
        setCurrentUser(targetUser);
        logAction('ROLE_CHANGE', undefined, undefined, `Beralih peran pengguna ke ${targetUser.roleTitle}`);
      }
    },
    [users, logAction]
  );

  const switchUser = useCallback(
    (userId: string) => {
      const targetUser = users.find((u) => u.id === userId);
      if (targetUser) {
        setCurrentUser(targetUser);
        logAction('LOGIN', undefined, undefined, `Masuk sebagai pengguna: ${targetUser.name} (${targetUser.email})`);
      }
    },
    [users, logAction]
  );

  // Register New User (Panel Admin)
  const registerUser = (
    userData: Omit<UserProfile, 'id' | 'createdAt'>
  ): { success: boolean; user?: UserProfile; error?: string } => {
    // Check if email already registered
    const existing = users.find((u) => u.email.toLowerCase() === userData.email.toLowerCase());
    if (existing) {
      return { success: false, error: `Email ${userData.email} sudah terdaftar dalam sistem.` };
    }

    const newUser: UserProfile = {
      ...userData,
      id: `USR-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      avatar:
        userData.avatar ||
        `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80`,
    };

    setUsers((prev) => [...prev, newUser]);
    logAction('USER_CREATE', newUser.id, newUser.name, `Pendaftaran pengguna baru: ${newUser.name} (${newUser.email}) sebagai ${newUser.role}`);

    // Notification
    const notif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Pendaftaran Pengguna Baru Berhasil',
      message: `Akun untuk ${newUser.name} (${newUser.email}) telah berhasil didaftarkan dengan peran ${newUser.roleTitle}.`,
      type: 'USER_MGMT',
      read: false,
      recipientEmail: newUser.email,
    };
    setNotifications((prev) => [notif, ...prev]);

    return { success: true, user: newUser };
  };

  const updateUser = (
    userId: string,
    userData: Partial<UserProfile>
  ): { success: boolean; error?: string } => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, ...userData } : u))
    );

    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({ ...prev, ...userData }));
    }

    logAction('USER_UPDATE', userId, userData.name, `Pembaruan data pengguna ID: ${userId}`);
    return { success: true };
  };

  const deleteUser = (userId: string): { success: boolean; error?: string } => {
    if (userId === currentUser.id) {
      return { success: false, error: 'Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif digunakan.' };
    }

    const target = users.find((u) => u.id === userId);
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    logAction('USER_DELETE', userId, target?.name, `Penghapusan akun pengguna: ${target?.name} (${target?.email})`);
    return { success: true };
  };

  // Connect Google Drive
  const connectGoogleDrive = async (): Promise<boolean> => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setIsGoogleConnected(true);
        logAction('GDRIVE_SYNC', undefined, undefined, `Berhasil menghubungkan Google Drive akun: ${res.user.email}`);
        await getOrCreateAppFolder();
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Failed to connect Google Drive:', err);
      logAction('GDRIVE_SYNC', undefined, undefined, `Gagal otentikasi Google Drive: ${err.message}`, 'WARNING');
      return false;
    }
  };

  // Connect Simulated Drive (Bypass for testing without Google verification block)
  const connectSimulatedDrive = (email: string = 'budikarabbani2@gmail.com') => {
    const simulatedUser = {
      email,
      displayName: 'Budika Rabbani (Akun Terverifikasi)',
      uid: 'user-budika-haji-test',
    } as any;
    setGoogleUser(simulatedUser);
    setIsGoogleConnected(true);
    logAction('GDRIVE_SYNC', undefined, undefined, `Mode Uji Coba Cloud Drive aktif untuk akun: ${email}`);
  };

  // Disconnect Google Drive
  const disconnectGoogleDrive = async () => {
    await logoutGoogle();
    setGoogleUser(null);
    setIsGoogleConnected(false);
    logAction('LOGOUT', undefined, undefined, 'Memutuskan koneksi akun Google Drive');
  };

  // Add document with optional encryption
  const addDocument = async (
    docData: Omit<ArchiveDocument, 'id' | 'uploadDate' | 'sha256Hash' | 'gdriveSynced'>,
    plainContent: string = '',
    passphrase?: string
  ): Promise<{ success: boolean; docId?: string; error?: string }> => {
    try {
      const id = `DOC-HAJI-${Date.now().toString().slice(-6)}`;
      const uploadDate = new Date().toISOString();
      const rawContentToHash = plainContent || docData.summary || docData.title;
      const sha256Hash = await computeSHA256(rawContentToHash);

      let encryptedPayload = undefined;
      let isEncrypted = docData.isEncrypted;

      if (isEncrypted) {
        const encryptionKey = passphrase || 'BUDIKA-ARSIF-HAJI-SECURE-2026';
        const encResult = await encryptDocument(plainContent || docData.summary, encryptionKey);
        encryptedPayload = encResult;
      }

      const newDoc: ArchiveDocument = {
        ...docData,
        id,
        uploadDate,
        sha256Hash,
        isEncrypted,
        encryptedContent: encryptedPayload?.ciphertext,
        encryptionIv: encryptedPayload?.iv,
        encryptionSalt: encryptedPayload?.salt,
        fileData: isEncrypted ? undefined : plainContent,
        gdriveSynced: false,
      };

      // Auto sync to Google Drive if connected
      const token = await getAccessToken();
      if (token) {
        try {
          const uploadRes = await uploadToGoogleDrive({
            fileName: newDoc.fileName,
            content: isEncrypted
              ? JSON.stringify({
                  title: newDoc.title,
                  docNumber: newDoc.docNumber,
                  encryptedPayload,
                  sha256Hash,
                })
              : plainContent || newDoc.summary,
            mimeType: 'application/json',
            isEncrypted,
            metadataDescription: `BUDIKA ARSIP: ${newDoc.title} (${newDoc.docNumber})`,
          });
          if (uploadRes.success && uploadRes.fileId) {
            newDoc.gdriveSynced = true;
            newDoc.gdriveFileId = uploadRes.fileId;
            newDoc.gdriveLink = uploadRes.webViewLink;
          }
        } catch (driveErr) {
          console.warn('Silent drive upload error:', driveErr);
        }
      }

      setDocuments((prev) => [newDoc, ...prev]);

      logAction(
        isEncrypted ? 'ENCRYPT' : 'UPLOAD',
        newDoc.id,
        newDoc.title,
        `Dokumen baru berhasil disimpan [Kategori: ${newDoc.category}, Keamanan: ${newDoc.securityLevel}]${
          newDoc.gdriveSynced ? ' & Tersinkron ke Google Drive' : ''
        }`
      );

      // Notification
      const newNotif: NotificationItem = {
        id: `NOTIF-${Date.now()}`,
        timestamp: new Date().toISOString(),
        title: 'Dokumen Baru Disimpan',
        message: `Dokumen "${newDoc.title}" (${newDoc.docNumber}) berhasil ditambahkan ke bank arsip.`,
        type: newDoc.gdriveSynced ? 'GDRIVE' : 'STATUS_CHANGE',
        read: false,
        docId: newDoc.id,
        channel: 'IN_APP',
      };
      setNotifications((prev) => [newNotif, ...prev]);

      return { success: true, docId: newDoc.id };
    } catch (err: any) {
      console.error('Failed to add document:', err);
      return { success: false, error: err.message || 'Gagal menyimpan dokumen' };
    }
  };

  // Update status (Verify, Approve, Reject, Archive)
  const updateDocumentStatus = async (
    docId: string,
    status: DocumentStatus,
    dispositionNotes?: string
  ): Promise<boolean> => {
    const doc = documents.find((d) => d.id === docId);
    if (!doc) return false;

    const updatedDocs = documents.map((d) => {
      if (d.id === docId) {
        return {
          ...d,
          status,
          dispositionNotes: dispositionNotes || d.dispositionNotes,
          lastVerifiedBy: currentUser.name,
          lastVerifiedAt: new Date().toISOString(),
        };
      }
      return d;
    });

    setDocuments(updatedDocs);

    let actionType: ActionType = 'VERIFY';
    if (status === 'Diarsipkan') actionType = 'APPROVE';
    if (status === 'Ditolak') actionType = 'REJECT';

    logAction(
      actionType,
      doc.id,
      doc.title,
      `Status dokumen diperbarui menjadi "${status}". Catatan: ${dispositionNotes || '-'}`
    );

    triggerStatusNotification(doc, status, dispositionNotes);
    return true;
  };

  // Delete single document
  const deleteDocument = async (docId: string): Promise<boolean> => {
    const doc = documents.find((d) => d.id === docId);
    if (!doc) return false;

    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    logAction('DELETE', doc.id, doc.title, `Dokumen ${doc.docNumber} ("${doc.title}") berhasil dihapus dari sistem kearsipan.`);

    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      timestamp: new Date().toISOString(),
      title: 'Dokumen Dihapus',
      message: `Berkas "${doc.title}" (${doc.docNumber}) telah dihapus dari bank arsip.`,
      type: 'STATUS_CHANGE',
      read: false,
      channel: 'IN_APP',
    };
    setNotifications((prev) => [newNotif, ...prev]);

    return true;
  };

  // Bulk delete documents
  const bulkDeleteDocuments = async (
    docIds: string[]
  ): Promise<{ success: boolean; count: number }> => {
    if (docIds.length === 0) return { success: true, count: 0 };

    setDocuments((prev) => prev.filter((d) => !docIds.includes(d.id)));
    logAction('BULK_DELETE', undefined, undefined, `${docIds.length} berkas dokumen dihapus secara massal oleh ${currentUser.name}`);

    return { success: true, count: docIds.length };
  };

  // Decrypt document on demand
  const decryptDoc = async (
    docId: string,
    passphrase: string
  ): Promise<{ success: boolean; content?: string; error?: string }> => {
    const doc = documents.find((d) => d.id === docId);
    if (!doc) return { success: false, error: 'Dokumen tidak ditemukan' };

    if (!doc.isEncrypted || !doc.encryptedContent || !doc.encryptionIv || !doc.encryptionSalt) {
      return { success: true, content: doc.fileData || doc.summary };
    }

    const res = await decryptDocument(
      doc.encryptedContent,
      doc.encryptionIv,
      doc.encryptionSalt,
      passphrase
    );

    if (res.success) {
      logAction('DECRYPT', doc.id, doc.title, `Dekripsi dokumen berhasil oleh ${currentUser.name}`);
    } else {
      logAction('DECRYPT', doc.id, doc.title, 'Percobaan dekripsi gagal: Kunci tidak sesuai', 'WARNING');
    }

    return res;
  };

  // Sync single document to Google Drive
  const syncDocumentToDrive = async (
    docId: string
  ): Promise<{ success: boolean; error?: string }> => {
    const doc = documents.find((d) => d.id === docId);
    if (!doc) return { success: false, error: 'Dokumen tidak ditemukan' };

    const token = await getAccessToken();
    if (!token) {
      if (isGoogleConnected) {
        // Simulated / Offline Drive mode
        setDocuments((prev) =>
          prev.map((d) =>
            d.id === docId
              ? {
                  ...d,
                  gdriveSynced: true,
                  gdriveFileId: `SIM-DRIVE-${Date.now()}`,
                  gdriveWebViewLink: `https://drive.google.com/drive/u/0/my-drive`,
                }
              : d
          )
        );
        logAction(
          'GDRIVE_SYNC',
          doc.id,
          doc.title,
          `Berkas tersinkron ke Google Drive (${APP_FOLDER_NAME}) [Mode Uji Coba Cloud]`
        );
        return { success: true };
      }
      return {
        success: false,
        error: 'Google Drive belum terhubung. Silakan hubungkan akun Google di bar navigasi atas.',
      };
    }

    try {
      const payloadContent = doc.isEncrypted
        ? JSON.stringify({
            id: doc.id,
            title: doc.title,
            docNumber: doc.docNumber,
            category: doc.category,
            encryptedContent: doc.encryptedContent,
            iv: doc.encryptionIv,
            salt: doc.encryptionSalt,
            sha256Hash: doc.sha256Hash,
          })
        : doc.fileData || doc.summary;

      const uploadRes = await uploadToGoogleDrive({
        fileName: doc.fileName,
        content: payloadContent,
        mimeType: 'application/json',
        isEncrypted: doc.isEncrypted,
        metadataDescription: `BUDIKA ARSIP: ${doc.title} (${doc.docNumber})`,
      });

      if (!uploadRes.success || !uploadRes.fileId) {
        return { success: false, error: uploadRes.error || 'Gagal mengunggah ke Google Drive' };
      }

      setDocuments((prev) =>
        prev.map((d) =>
          d.id === docId
            ? {
                ...d,
                gdriveSynced: true,
                gdriveFileId: uploadRes.fileId,
                gdriveLink: uploadRes.webViewLink,
              }
            : d
        )
      );

      logAction('GDRIVE_SYNC', doc.id, doc.title, `Sinkronisasi dokumen ke Google Drive berhasil`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  // Sync all documents to Google Drive
  const syncAllToDrive = async (): Promise<{ success: boolean; count: number; error?: string }> => {
    const token = await getAccessToken();
    if (!token) {
      return {
        success: false,
        count: 0,
        error: 'Google Drive belum terhubung. Silakan klik tombol "Hubungkan Google Drive".',
      };
    }

    setIsSyncingGDrive(true);
    let syncedCount = 0;

    try {
      for (const doc of documents) {
        if (!doc.gdriveSynced) {
          const res = await syncDocumentToDrive(doc.id);
          if (res.success) syncedCount++;
        }
      }
      setLastGDriveSync(new Date().toISOString());
      logAction(
        'GDRIVE_SYNC',
        undefined,
        undefined,
        `Sinkronisasi massal ke Google Drive selesai: ${syncedCount} dokumen baru berhasil disinkronkan.`
      );
      return { success: true, count: syncedCount };
    } catch (err: any) {
      return { success: false, count: syncedCount, error: err.message };
    } finally {
      setIsSyncingGDrive(false);
    }
  };

  // Notifications
  const markNotifAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotifsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const triggerStatusNotification = (
    doc: ArchiveDocument,
    newStatus: DocumentStatus,
    notes?: string
  ) => {
    const notifTitle = `Status Dokumen: ${newStatus}`;
    const notifMessage = `Dokumen "${doc.title}" (${doc.docNumber}) telah berstatus "${newStatus}". Disposisi: ${
      notes || 'Tidak ada catatan'
    }`;

    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      title: notifTitle,
      message: notifMessage,
      type: 'STATUS_CHANGE',
      read: false,
      docId: doc.id,
      recipientEmail: doc.ownerEmail,
      channel: 'IN_APP',
    };

    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Backup & Restore
  const createBackupBundle = async (toGoogleDrive: boolean = false) => {
    try {
      const now = new Date().toISOString();
      const backupData = {
        app: 'BUDIKA ARSIP - KEMENTERIAN HAJI DAN UMRAH RI',
        version: '3.0.0-ENTERPRISE',
        exportedAt: now,
        exportedBy: {
          nip: currentUser.nip,
          name: currentUser.name,
          email: currentUser.email,
          role: currentUser.role,
        },
        metadata: {
          totalUsers: users.length,
          totalDocuments: documents.length,
          totalEncrypted: documents.filter((d) => d.isEncrypted).length,
          totalPersonnelDocs: documents.filter((d) => d.isPersonnelFile).length,
          totalLogs: logs.length,
        },
        users,
        documents,
        logs,
      };

      const jsonString = JSON.stringify(backupData, null, 2);
      const checksum = await computeSHA256(jsonString);

      if (toGoogleDrive) {
        const token = await getAccessToken();
        if (token) {
          const fileName = `Backup_BUDIKA_ARSIF_${new Date().toISOString().slice(0, 10)}.json`;
          await uploadToGoogleDrive({
            fileName,
            content: jsonString,
            mimeType: 'application/json',
            isEncrypted: false,
            metadataDescription: `Cadangan Sistem Otomatis BUDIKA ARSIP (${checksum.slice(0, 12)})`,
          });
        }
      }

      setLastBackupTime(now);
      logAction('BACKUP', undefined, undefined, `Pencadangan data kearsipan dibuat (SHA-256: ${checksum.slice(0, 16)}...)`);
      return { success: true, jsonString };
    } catch (err: any) {
      return { success: false, error: err.message || 'Gagal membuat cadangan' };
    }
  };

  const restoreBackupBundle = async (
    jsonString: string
  ): Promise<{ success: boolean; restoredDocs: number; error?: string }> => {
    try {
      const data = JSON.parse(jsonString);
      if (!data.documents || !Array.isArray(data.documents)) {
        return { success: false, restoredDocs: 0, error: 'Format berkas cadangan tidak valid.' };
      }

      setDocuments(data.documents);
      if (data.users && Array.isArray(data.users)) {
        setUsers(data.users);
      }
      if (data.logs && Array.isArray(data.logs)) {
        setLogs(data.logs);
      }

      logAction('RESTORE', undefined, undefined, `Pemulihan data cadangan berhasil: ${data.documents.length} dokumen dan ${data.users?.length || 0} akun pengguna dipulihkan.`);
      return { success: true, restoredDocs: data.documents.length };
    } catch (err: any) {
      return { success: false, restoredDocs: 0, error: err.message || 'Gagal mengurai berkas cadangan' };
    }
  };

  // Export audit logs to CSV
  const exportLogsToCSV = () => {
    const headers = ['ID Log', 'Waktu (UTC)', 'NIP', 'Nama Pengguna', 'Email', 'Peran', 'Aksi', 'ID Dokumen', 'Judul Dokumen', 'Status', 'IP & Lokasi', 'Perangkat', 'Detail', 'Hash Audit'];
    const rows = logs.map((l) => [
      l.id,
      l.timestamp,
      l.user.nip,
      `"${l.user.name}"`,
      l.user.email || '-',
      l.user.role,
      l.action,
      l.targetId || '-',
      `"${(l.targetTitle || '-').replace(/"/g, '""')}"`,
      l.status,
      `"${l.ipAddress}"`,
      `"${l.device}"`,
      `"${l.details.replace(/"/g, '""')}"`,
      l.hash,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Audit_Log_BUDIKA_ARSIF_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    logAction('EXPORT', undefined, undefined, 'Mengunduh laporan audit log pengguna dalam format CSV');
  };

  return (
    <ArchiveContext.Provider
      value={{
        currentUser,
        users,
        switchRole,
        switchUser,
        registerUser,
        updateUser,
        deleteUser,
        isGoogleConnected,
        googleUser,
        connectGoogleDrive,
        connectSimulatedDrive,
        disconnectGoogleDrive,
        gdriveFolderName: APP_FOLDER_NAME,
        isSyncingGDrive,
        lastGDriveSync,
        syncDocumentToDrive,
        syncAllToDrive,
        documents,
        addDocument,
        updateDocumentStatus,
        deleteDocument,
        bulkDeleteDocuments,
        decryptDoc,
        logs,
        logAction,
        exportLogsToCSV,
        notifications,
        markNotifAsRead,
        markAllNotifsRead,
        triggerStatusNotification,
        autoBackupEnabled,
        setAutoBackupEnabled,
        backupSchedule,
        setBackupSchedule,
        lastBackupTime,
        createBackupBundle,
        restoreBackupBundle,
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedDocumentForDetail,
        setSelectedDocumentForDetail,
        isUploadModalOpen,
        setIsUploadModalOpen,
        uploadInitialPersonnelOnly,
        setUploadInitialPersonnelOnly,
      }}
    >
      {children}
    </ArchiveContext.Provider>
  );
};

export const useArchive = () => {
  const context = useContext(ArchiveContext);
  if (!context) {
    throw new Error('useArchive must be used within an ArchiveProvider');
  }
  return context;
};
